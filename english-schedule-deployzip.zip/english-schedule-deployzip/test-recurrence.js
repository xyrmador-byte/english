import assert from 'node:assert/strict';
import { formatDateIso, getWeekDays } from './src/lib/dateUtils.js';
import {
  computeDisplayLessons,
  findScheduleConflicts,
  getOccurrenceDate,
  shiftWeekdays,
} from './src/lib/schedule.js';

const date = (year, monthIndex, day) => new Date(year, monthIndex, day, 12);
const octoberWeek = getWeekDays(date(2026, 9, 12));

const tueThuRule = {
  id: 'rule-tue-thu',
  teacher_id: 'teacher-1',
  student_id: 'student-1',
  student: { id: 'student-1', name: 'Анна' },
  freq: 'weekly',
  by_weekdays: [2, 4],
  start_date: '2026-10-01',
  start_time: '16:00:00',
  duration_minutes: 60,
  until_date: null,
};

const movedTuesday = {
  id: 'exception-tuesday',
  teacher_id: 'teacher-1',
  student_id: 'student-1',
  student: { id: 'student-1', name: 'Анна' },
  recurrence_rule_id: tueThuRule.id,
  original_date: '2026-10-13',
  date: '2026-10-15',
  start_time: '18:00:00',
  duration_minutes: 60,
  status: 'scheduled',
  is_exception: true,
};

const oneOffWednesday = {
  id: 'oneoff-wednesday',
  student_id: 'student-2',
  date: '2026-10-14',
  start_time: '11:00:00',
  duration_minutes: 45,
  status: 'scheduled',
};

const movedWeek = computeDisplayLessons(
  octoberWeek,
  [tueThuRule],
  [movedTuesday, oneOffWednesday]
);
assert.equal(movedWeek.filter((lesson) => lesson.date === '2026-10-13').length, 0);
assert.deepEqual(
  movedWeek.filter((lesson) => lesson.date === '2026-10-15').map((lesson) => lesson.start_time),
  ['16:00:00', '18:00:00']
);
assert.equal(movedWeek.length, 3);

const cancelledTuesday = {
  ...movedTuesday,
  id: 'cancelled-tuesday',
  original_date: '2026-10-13',
  date: '2026-10-13',
  status: 'cancelled',
};
const cancelledWeek = computeDisplayLessons(octoberWeek, [tueThuRule], [cancelledTuesday]);
assert.equal(cancelledWeek.find((lesson) => lesson.date === '2026-10-13')?.status, 'cancelled');
assert.equal(
  cancelledWeek.filter((lesson) => lesson.date === '2026-10-13' && lesson.status === 'scheduled').length,
  0
);

// A moved lesson whose original occurrence was in the previous week still
// appears at its new date.
const previousFridayRule = {
  ...tueThuRule,
  id: 'rule-friday',
  freq: 'weekly',
  by_weekdays: [5],
};
const movedFromPreviousWeek = {
  ...movedTuesday,
  id: 'exception-from-previous-week',
  recurrence_rule_id: previousFridayRule.id,
  original_date: '2026-10-09',
  date: '2026-10-13',
  start_time: '18:00:00',
};
const movedInWeek = computeDisplayLessons(octoberWeek, [previousFridayRule], [movedFromPreviousWeek]);
assert.equal(
  movedInWeek.filter((lesson) => lesson.date === '2026-10-13').length,
  1
);
assert.equal(movedInWeek[0].original_date, '2026-10-09');
assert.equal(getOccurrenceDate({ date: '2026-10-13' }), '2026-10-13');

// Daily recurrences continue across month boundaries and obey their end date.
const monthBoundaryDays = getWeekDays(date(2026, 9, 26));
const dailyRule = {
  ...tueThuRule,
  id: 'daily-rule',
  freq: 'daily',
  by_weekdays: [1, 2, 3, 4, 5, 6, 7],
  start_date: '2026-10-30',
  until_date: '2026-11-02',
  start_time: '09:00:00',
};
const monthBoundary = computeDisplayLessons(monthBoundaryDays, [dailyRule], []);
assert.deepEqual(
  monthBoundary.map((lesson) => lesson.date),
  ['2026-10-30', '2026-10-31', '2026-11-01']
);
const novemberWeek = getWeekDays(date(2026, 10, 2));
assert.deepEqual(
  computeDisplayLessons(novemberWeek, [dailyRule], []).map((lesson) => lesson.date),
  ['2026-11-02']
);

// The calendar date and local wall-clock time remain stable across DST changes.
const sundayBeforeDst = getWeekDays(date(2026, 9, 19));
const sundayAfterDst = getWeekDays(date(2026, 9, 26));
const sundayRule = {
  ...tueThuRule,
  id: 'sunday-rule',
  by_weekdays: [7],
  start_time: '10:00:00',
};
assert.equal(computeDisplayLessons(sundayBeforeDst, [sundayRule], [])[0].start_time, '10:00:00');
assert.equal(computeDisplayLessons(sundayAfterDst, [sundayRule], [])[0].start_time, '10:00:00');

assert.deepEqual(shiftWeekdays([2, 4], -1), [1, 3]);
assert.deepEqual(shiftWeekdays([1, 7], 1), [1, 2]);

const recurringConflict = findScheduleConflicts({
  candidate: {
    freq: 'weekly',
    by_weekdays: [2, 4],
    start_date: '2026-10-12',
    until_date: '2026-10-31',
    start_time: '16:00',
    duration_minutes: 60,
  },
  existingRules: [{
    ...tueThuRule,
    freq: 'daily',
    start_date: '2026-10-15',
    until_date: '2026-10-16',
    start_time: '16:30',
    duration_minutes: 45,
  }],
});
assert.equal(recurringConflict.length, 1);
assert.equal(recurringConflict[0].date, '2026-10-15');
assert.equal(recurringConflict[0].end_time, '17:15');

const noBoundaryConflict = findScheduleConflicts({
  candidate: {
    date: '2026-10-15',
    start_time: '17:00',
    duration_minutes: 30,
  },
  existingRules: [{
    ...tueThuRule,
    start_date: '2026-10-01',
    start_time: '16:00',
    duration_minutes: 60,
  }],
});
assert.equal(noBoundaryConflict.length, 0);

const skippedCancelledOccurrence = findScheduleConflicts({
  candidate: {
    freq: 'weekly',
    by_weekdays: [4],
    start_date: '2026-10-15',
    start_time: '16:00',
    duration_minutes: 60,
  },
  existingLessons: [{
    recurrence_rule_id: 'daily-existing',
    original_date: '2026-10-15',
    date: '2026-10-15',
    status: 'cancelled',
    is_exception: true,
    id: 'cancelled-exception',
  }],
  existingRules: [{
    ...tueThuRule,
    id: 'daily-existing',
    freq: 'daily',
    start_date: '2026-10-15',
    until_date: '2026-10-31',
    start_time: '16:30',
    duration_minutes: 45,
  }],
});
assert.equal(skippedCancelledOccurrence[0].date, '2026-10-22');

const editingSameRecurringOccurrence = findScheduleConflicts({
  candidate: {
    date: '2026-10-15',
    start_time: '16:00',
    duration_minutes: 60,
  },
  existingRules: [{
    ...tueThuRule,
    freq: 'daily',
    start_date: '2026-10-01',
  }],
  excludeRuleOccurrence: {
    ruleId: tueThuRule.id,
    date: '2026-10-15',
  },
});
assert.equal(editingSameRecurringOccurrence.length, 0);

const endedRuleConflict = findScheduleConflicts({
  candidate: {
    freq: 'daily',
    start_date: '2026-11-01',
    start_time: '16:30',
    duration_minutes: 45,
  },
  existingRules: [{
    ...tueThuRule,
    start_date: '2026-10-01',
    until_date: '2026-10-31',
  }],
});
assert.equal(endedRuleConflict.length, 0);

assert.equal(formatDateIso(octoberWeek[0]), '2026-10-12');
console.log('Проверки повторов, исключений, переносов и конфликтов пройдены.');
