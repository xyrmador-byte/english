# Project setup

## Run in Replit

This is a Vite + React project. The source, tests, and build scripts are in the
workspace.

The Replit workflow runs:

```sh
npm run dev -- --host 0.0.0.0 --port 5000
```

Use `npm test` for the schedule logic tests and `npm run build` for a production
build.

## Supabase setup required for app features

Authentication, students, lessons, and recurrence data stay in Supabase. Keep
the existing Supabase project; do not migrate it to a different database.

1. If the project has no app tables, run `schema.sql`, then
   `supabase/migrations/20261010000000_schedule_safety.sql` in Supabase SQL
   Editor.
2. If the app tables already exist, run only the additive migration. Do not
   recreate tables or use destructive resets.
3. Enter the Project URL and public `anon`/publishable key in the app's
   connection screen. Never enter a `service_role` key in the browser.

The current Supabase API reports that the app tables are missing. Until the
schema and migration are applied, database-backed features cannot be tested or
used. The app now reports this as a setup issue instead of flooding the console
with separate table errors.
