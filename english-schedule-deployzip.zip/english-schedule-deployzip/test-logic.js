import assert from 'node:assert/strict';
import {
  addMinutesToTime,
  formatDateIso,
  getMondayOfWeek,
  getTodayIso,
  getWeekDays,
  getWeekdayNumber,
  isTimeOverlapping,
} from './src/lib/dateUtils.js';

const thursday = new Date(2026, 9, 15, 12);
const monday = getMondayOfWeek(thursday);
assert.equal(formatDateIso(monday), '2026-10-12');

const weekDays = getWeekDays(monday);
assert.equal(weekDays.length, 7);
assert.equal(formatDateIso(weekDays[6]), '2026-10-18');
assert.equal(getWeekdayNumber(weekDays[0]), 1);
assert.equal(getWeekdayNumber(weekDays[6]), 7);

assert.equal(addMinutesToTime('14:30', 45), '15:15');
assert.equal(addMinutesToTime('18:00', 90), '19:30');
assert.equal(isTimeOverlapping('10:00', 60, '10:30', 45), true);
assert.equal(isTimeOverlapping('10:00', 60, '11:00', 60), false);
assert.equal(isTimeOverlapping('10:00', 60, '14:00', 60), false);

// Europe/Bratislava is already on the next calendar day at this instant.
assert.equal(
  getTodayIso('Europe/Bratislava', new Date('2026-10-24T22:30:00.000Z')),
  '2026-10-25'
);

console.log('Базовые проверки дат и конфликтов пройдены.');
