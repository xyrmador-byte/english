-- Additive and data-preserving repair for recurring lessons and history.
-- Run in Supabase SQL Editor. Existing rows are retained.
BEGIN;

ALTER TABLE public.lessons
  ADD COLUMN IF NOT EXISTS original_date date;

GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles, public.students,
  public.recurrence_rules, public.lessons TO authenticated;

-- Older versions did not record the occurrence date separately. For those
-- rows, the saved date is the only reliable value available.
UPDATE public.lessons
SET original_date = date
WHERE recurrence_rule_id IS NOT NULL
  AND is_exception = true
  AND original_date IS NULL;

DROP INDEX IF EXISTS public.idx_lessons_unique_rule_date;
CREATE UNIQUE INDEX IF NOT EXISTS idx_lessons_unique_rule_original_date
  ON public.lessons (recurrence_rule_id, original_date);

-- Composite keys let the database enforce that related records belong to the
-- same teacher, while RESTRICT prevents accidental history loss by cascade.
CREATE UNIQUE INDEX IF NOT EXISTS idx_students_id_teacher_id
  ON public.students (id, teacher_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_recurrence_rules_id_teacher_id
  ON public.recurrence_rules (id, teacher_id);

ALTER TABLE public.recurrence_rules
  DROP CONSTRAINT IF EXISTS recurrence_rules_student_id_fkey;
ALTER TABLE public.lessons
  DROP CONSTRAINT IF EXISTS lessons_student_id_fkey;
ALTER TABLE public.lessons
  DROP CONSTRAINT IF EXISTS lessons_recurrence_rule_id_fkey;

DO $migration$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'recurrence_rules_student_teacher_fkey'
      AND conrelid = 'public.recurrence_rules'::regclass
  ) THEN
    ALTER TABLE public.recurrence_rules
      ADD CONSTRAINT recurrence_rules_student_teacher_fkey
      FOREIGN KEY (student_id, teacher_id)
      REFERENCES public.students (id, teacher_id)
      ON DELETE RESTRICT NOT VALID;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'lessons_student_teacher_fkey'
      AND conrelid = 'public.lessons'::regclass
  ) THEN
    ALTER TABLE public.lessons
      ADD CONSTRAINT lessons_student_teacher_fkey
      FOREIGN KEY (student_id, teacher_id)
      REFERENCES public.students (id, teacher_id)
      ON DELETE RESTRICT NOT VALID;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'lessons_recurrence_teacher_fkey'
      AND conrelid = 'public.lessons'::regclass
  ) THEN
    ALTER TABLE public.lessons
      ADD CONSTRAINT lessons_recurrence_teacher_fkey
      FOREIGN KEY (recurrence_rule_id, teacher_id)
      REFERENCES public.recurrence_rules (id, teacher_id)
      ON DELETE RESTRICT NOT VALID;
  END IF;
END
$migration$;

CREATE OR REPLACE FUNCTION public.split_recurrence_series(
  p_rule_id uuid,
  p_occurrence_date date,
  p_new_start_date date,
  p_start_time time,
  p_duration_minutes integer,
  p_until_date date,
  p_note text,
  p_by_weekdays integer[]
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = ''
AS $function$
DECLARE
  v_rule public.recurrence_rules%ROWTYPE;
  v_new_rule_id uuid;
  v_day_delta integer;
BEGIN
  SELECT *
  INTO v_rule
  FROM public.recurrence_rules
  WHERE id = p_rule_id
    AND teacher_id = auth.uid()
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Recurrence rule not found or access denied'
      USING ERRCODE = '42501';
  END IF;
  IF p_occurrence_date < v_rule.start_date
     OR (v_rule.until_date IS NOT NULL AND p_occurrence_date > v_rule.until_date) THEN
    RAISE EXCEPTION 'Occurrence date is outside this series';
  END IF;
  IF p_until_date IS DISTINCT FROM v_rule.until_date THEN
    RAISE EXCEPTION 'Series changed while editing; reload and try again';
  END IF;
  IF p_new_start_date < p_occurrence_date THEN
    RAISE EXCEPTION 'New series date cannot precede the selected occurrence';
  END IF;
  IF v_rule.until_date IS NOT NULL AND p_new_start_date > v_rule.until_date THEN
    RAISE EXCEPTION 'New series date is after the series end date';
  END IF;
  IF p_duration_minutes NOT IN (30, 45, 60, 90) THEN
    RAISE EXCEPTION 'Unsupported lesson duration';
  END IF;
  IF v_rule.freq = 'weekly'
     AND (p_by_weekdays IS NULL OR cardinality(p_by_weekdays) = 0) THEN
    RAISE EXCEPTION 'Weekly series must include at least one weekday';
  END IF;

  v_day_delta := p_new_start_date - p_occurrence_date;

  IF p_occurrence_date > v_rule.start_date THEN
    UPDATE public.recurrence_rules
    SET until_date = p_occurrence_date - 1,
        updated_at = now()
    WHERE id = p_rule_id
      AND teacher_id = v_rule.teacher_id;
  END IF;

  INSERT INTO public.recurrence_rules (
    teacher_id,
    student_id,
    freq,
    by_weekdays,
    start_date,
    start_time,
    duration_minutes,
    until_date,
    note
  )
  VALUES (
    v_rule.teacher_id,
    v_rule.student_id,
    v_rule.freq,
    COALESCE(p_by_weekdays, v_rule.by_weekdays),
    p_new_start_date,
    p_start_time,
    p_duration_minutes,
    p_until_date,
    COALESCE(p_note, '')
  )
  RETURNING id INTO v_new_rule_id;

  -- Move future exceptions to the new rule and shift their original and actual
  -- dates together. Status-only exceptions follow the new series time; manually
  -- moved exceptions keep their own time and duration.
  UPDATE public.lessons
  SET recurrence_rule_id = v_new_rule_id,
      original_date = original_date + v_day_delta,
      date = date + v_day_delta,
      start_time = CASE
        WHEN date = original_date THEN p_start_time
        ELSE start_time
      END,
      duration_minutes = CASE
        WHEN date = original_date THEN p_duration_minutes
        ELSE duration_minutes
      END,
      note = CASE
        WHEN date = original_date THEN COALESCE(p_note, '')
        ELSE note
      END,
      updated_at = now()
  WHERE recurrence_rule_id = p_rule_id
    AND teacher_id = v_rule.teacher_id
    AND original_date >= p_occurrence_date;

  -- If the selected occurrence was the first one, there is no valid earlier
  -- interval to retain (until_date must not precede start_date).
  IF p_occurrence_date = v_rule.start_date THEN
    DELETE FROM public.recurrence_rules
    WHERE id = p_rule_id
      AND teacher_id = v_rule.teacher_id;
  END IF;

  RETURN v_new_rule_id;
END
$function$;

CREATE OR REPLACE FUNCTION public.delete_recurrence_series(p_rule_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = ''
AS $function$
DECLARE
  v_rule public.recurrence_rules%ROWTYPE;
  v_timezone text;
  v_today date;
BEGIN
  SELECT *
  INTO v_rule
  FROM public.recurrence_rules
  WHERE id = p_rule_id
    AND teacher_id = auth.uid()
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Recurrence rule not found or access denied'
      USING ERRCODE = '42501';
  END IF;

  SELECT timezone
  INTO v_timezone
  FROM public.profiles
  WHERE id = auth.uid();
  v_today := (now() AT TIME ZONE COALESCE(v_timezone, 'Europe/Bratislava'))::date;

  DELETE FROM public.lessons
  WHERE recurrence_rule_id = p_rule_id
    AND teacher_id = v_rule.teacher_id
    AND status = 'scheduled'
    AND date >= v_today;

  -- Retain completed and cancelled rows as history, independent of this rule.
  UPDATE public.lessons
  SET recurrence_rule_id = NULL,
      original_date = NULL,
      is_exception = false,
      updated_at = now()
  WHERE recurrence_rule_id = p_rule_id
    AND teacher_id = v_rule.teacher_id;

  DELETE FROM public.recurrence_rules
  WHERE id = p_rule_id
    AND teacher_id = v_rule.teacher_id;
END
$function$;

REVOKE ALL ON FUNCTION public.split_recurrence_series(
  uuid, date, date, time, integer, date, text, integer[]
) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.split_recurrence_series(
  uuid, date, date, time, integer, date, text, integer[]
) TO authenticated;
REVOKE ALL ON FUNCTION public.delete_recurrence_series(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.delete_recurrence_series(uuid) TO authenticated;

COMMIT;
