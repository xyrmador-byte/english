import React, { useState, useEffect } from 'react';
import {
  X,
  Clock,
  Calendar as CalendarIcon,
  User,
  Repeat,
  AlertTriangle,
  Loader2,
  Trash2,
  Edit2,
  CheckCircle2,
  XCircle,
  FileText,
  Phone,
} from 'lucide-react';
import { DURATION_OPTIONS, STATUS_CONFIG } from '../lib/types';
import {
  formatDateReadable,
  formatDateFull,
  formatTime,
  addMinutesToTime,
  timeToMinutes,
} from '../lib/dateUtils';
import { getSupabase } from '../lib/supabase';
import { findScheduleConflicts, getOccurrenceDate, shiftWeekdays } from '../lib/schedule';

function getCalendarDayDelta(fromDate, toDate) {
  if (!fromDate || !toDate) return 0;
  return Math.round(
    (Date.parse(`${toDate}T00:00:00.000Z`) - Date.parse(`${fromDate}T00:00:00.000Z`)) /
      86400000
  );
}

export default function LessonModal({
  isOpen,
  onClose,
  lesson,
  existingLessons = [],
  recurrenceRules = [],
  onLessonUpdated,
  showToast,
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [editDate, setEditDate] = useState('');
  const [editTime, setEditTime] = useState('');
  const [editDuration, setEditDuration] = useState(60);
  const [editNote, setEditNote] = useState('');

  // Выбор области действия для повторяющихся уроков ('single' | 'future')
  const [recurrenceScope, setRecurrenceScope] = useState('single');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [deleteSeriesOpen, setDeleteSeriesOpen] = useState(false);

  useEffect(() => {
    if (lesson) {
      setIsEditing(false);
      setEditDate(lesson.date);
      setEditTime(formatTime(lesson.start_time));
      setEditDuration(lesson.duration_minutes || 60);
      setEditNote(lesson.note || '');
      setRecurrenceScope('single');
      setConfirmDeleteOpen(false);
      setDeleteSeriesOpen(false);
    }
  }, [lesson]);

  if (!isOpen || !lesson) return null;

  const supabase = getSupabase();
  const isRecurring = Boolean(lesson.recurrence_rule_id || lesson.is_recurring);
  const originalOccurrenceDate = getOccurrenceDate(lesson);
  const dateDelta = getCalendarDayDelta(originalOccurrenceDate, editDate);
  const oldRule = lesson.recurrence_rule;
  const shiftedWeekdays = shiftWeekdays(oldRule?.by_weekdays || [], dateDelta);
  const appliesToFuture = isRecurring && recurrenceScope === 'future';
  const editCandidate = {
    ...(appliesToFuture
      ? {
          freq: oldRule?.freq,
          by_weekdays: oldRule?.freq === 'weekly' ? shiftedWeekdays : oldRule?.by_weekdays,
          start_date: editDate,
          until_date: oldRule?.until_date || null,
        }
      : { date: editDate }),
    start_time: formatTime(editTime),
    duration_minutes: Number(editDuration),
  };
  const editConflicts = isEditing
    ? findScheduleConflicts({
        candidate: editCandidate,
        existingLessons,
        existingRules: recurrenceRules,
        excludeLessonId: lesson.id,
        excludeRuleId: appliesToFuture ? lesson.recurrence_rule_id : null,
        excludeRuleOccurrence:
          isRecurring && !appliesToFuture
            ? { ruleId: lesson.recurrence_rule_id, date: originalOccurrenceDate }
            : null,
      })
    : [];
  const conflictWarning = editConflicts.length
    ? `Пересечение ${formatDateFull(editConflicts[0].date)}: занятие с «${editConflicts[0].student_name}» (${formatTime(editConflicts[0].start_time)}–${editConflicts[0].end_time}).`
    : null;
  const invalidEditTime = timeToMinutes(editTime) + Number(editDuration) > 24 * 60;
  const invalidFutureDate = appliesToFuture && editDate < originalOccurrenceDate;
  const invalidFutureEndDate =
    appliesToFuture && oldRule?.until_date && editDate > oldRule.until_date;
  const editValidationWarning = invalidEditTime
    ? 'Урок не может завершаться после полуночи.'
    : invalidFutureDate
      ? 'Дата серии не может быть раньше выбранного занятия.'
      : invalidFutureEndDate
        ? 'Дата серии не может быть позже даты её окончания.'
        : null;
  const endTime = addMinutesToTime(lesson.start_time, lesson.duration_minutes);
  const editEndTime = addMinutesToTime(editTime, editDuration);

  // Быстрая смена статуса (Запланирован / Проведён / Отменён)
  const handleStatusChange = async (newStatus) => {
    if (!supabase) return;
    setIsSubmitting(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error('Пользователь не авторизован');

      if (isRecurring && !lesson.is_exception) {
        // Создаем исключение для этой даты с новым статусом
        const { error } = await supabase.from('lessons').upsert(
          {
            teacher_id: user.id,
            student_id: lesson.student_id,
            recurrence_rule_id: lesson.recurrence_rule_id,
            original_date: originalOccurrenceDate,
            date: lesson.date,
            start_time: formatTime(lesson.start_time) + ':00',
            duration_minutes: lesson.duration_minutes,
            note: lesson.note || '',
            status: newStatus,
            is_exception: true,
          },
          { onConflict: 'recurrence_rule_id,original_date' }
        );

        if (error) throw error;
      } else {
        // Обычный урок или уже существующее исключение
        const { error } = await supabase
          .from('lessons')
          .update({ status: newStatus, updated_at: new Date().toISOString() })
          .eq('id', lesson.id);

        if (error) throw error;
      }

      showToast({
        type: 'success',
        title: 'Статус обновлен',
        message: `Урок отмечен как «${STATUS_CONFIG[newStatus]?.label}»`,
      });
      onLessonUpdated();
      onClose();
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Ошибка обновления статуса' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Сохранение изменений в уроке
  const handleSaveEdit = async (e) => {
    e.preventDefault();
    if (!supabase) return;
    if (invalidEditTime) {
      showToast({ type: 'warning', message: 'Урок должен завершаться до полуночи.' });
      return;
    }
    if (invalidFutureDate) {
      showToast({
        type: 'warning',
        message: 'Для изменения серии выберите дату не раньше исходного урока.',
      });
      return;
    }
    if (invalidFutureEndDate) {
      showToast({
        type: 'warning',
        message: 'Новая дата выходит за установленный конец серии.',
      });
      return;
    }
    if (editConflicts.length) {
      showToast({
        type: 'error',
        title: 'В расписании уже есть урок',
        message: conflictWarning,
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error('Пользователь не авторизован');

      const cleanStartTime = formatTime(editTime) + ':00';

      if (isRecurring && recurrenceScope === 'future') {
        if (!oldRule) throw new Error('Не удалось найти правило повторения этого урока');
        const { error: splitError } = await supabase.rpc('split_recurrence_series', {
          p_rule_id: oldRule.id,
          p_occurrence_date: originalOccurrenceDate,
          p_new_start_date: editDate,
          p_start_time: cleanStartTime,
          p_duration_minutes: editDuration,
          p_until_date: oldRule.until_date,
          p_note: editNote.trim(),
          p_by_weekdays:
            oldRule.freq === 'weekly' ? shiftedWeekdays : oldRule.by_weekdays,
        });
        if (splitError) throw splitError;

        showToast({
          type: 'success',
          title: 'Серия обновлена',
          message: 'Этот и все последующие уроки обновлены',
        });
      } else if (isRecurring) {
        // «Изменить только этот урок» -> создаем/обновляем запись исключения
        const { error } = await supabase.from('lessons').upsert(
          {
            teacher_id: user.id,
            student_id: lesson.student_id,
            recurrence_rule_id: lesson.recurrence_rule_id,
            original_date: originalOccurrenceDate,
            date: editDate,
            start_time: cleanStartTime,
            duration_minutes: editDuration,
            note: editNote.trim(),
            status: lesson.status || 'scheduled',
            is_exception: true,
          },
          { onConflict: 'recurrence_rule_id,original_date' }
        );

        if (error) throw error;

        showToast({
          type: 'success',
          title: 'Урок изменен',
          message: 'Изменения сохранены для этого занятия',
        });
      } else {
        // Обычный разовый урок
        const { error } = await supabase
          .from('lessons')
          .update({
            date: editDate,
            start_time: cleanStartTime,
            duration_minutes: editDuration,
            note: editNote.trim(),
            updated_at: new Date().toISOString(),
          })
          .eq('id', lesson.id);

        if (error) throw error;

        showToast({
          type: 'success',
          title: 'Урок обновлен',
          message: 'Изменения успешно сохранены',
        });
      }

      onLessonUpdated();
      onClose();
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Не удалось сохранить изменения' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Удаление только этого урока
  const handleDeleteSingle = async () => {
    if (!supabase) return;
    setIsSubmitting(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (lesson.status === 'completed') {
        throw new Error('Проведённый урок нельзя удалить: он сохранён в истории.');
      }

      if (isRecurring) {
        // Оставляем отменённую запись-исключение, чтобы урок не появился снова.
        const { error } = await supabase.from('lessons').upsert(
          {
            teacher_id: user.id,
            student_id: lesson.student_id,
            recurrence_rule_id: lesson.recurrence_rule_id,
            original_date: originalOccurrenceDate,
            date: lesson.date,
            start_time: formatTime(lesson.start_time) + ':00',
            duration_minutes: lesson.duration_minutes,
            note: 'Занятие отменено',
            status: 'cancelled',
            is_exception: true,
          },
          { onConflict: 'recurrence_rule_id,original_date' }
        );

        if (error) throw error;
      } else {
        const { error } = await supabase.from('lessons').delete().eq('id', lesson.id);
        if (error) throw error;
      }

      showToast({
        type: 'success',
        title: 'Урок удален',
        message: 'Занятие удалено из расписания',
      });
      onLessonUpdated();
      onClose();
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Ошибка удаления урока' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Удаление всей серии повторяющихся уроков
  const handleDeleteWholeSeries = async () => {
    if (!supabase) return;
    setIsSubmitting(true);
    try {
      const ruleId = lesson.recurrence_rule_id;
      if (ruleId) {
        const { error } = await supabase.rpc('delete_recurrence_series', {
          p_rule_id: ruleId,
        });
        if (error) throw error;
      }

      showToast({
        type: 'success',
        title: 'Серия уроков завершена',
        message: 'Будущие занятия удалены, история уроков сохранена',
      });
      onLessonUpdated();
      onClose();
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Ошибка удаления серии уроков' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const statusInfo = STATUS_CONFIG[lesson.status] || STATUS_CONFIG.scheduled;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full my-6 p-5 sm:p-7 border border-slate-100 max-h-[92vh] overflow-y-auto">
        {/* Заголовок */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className={`w-3 h-3 rounded-full ${statusInfo.indicatorDot}`} />
            <h2 className="text-lg font-bold text-slate-800">
              {isEditing ? 'Редактирование урока' : 'Информация об уроке'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Режим просмотра */}
        {!isEditing && (
          <div className="mt-4 space-y-4">
            {/* Карточка ученика и статус */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-xs text-slate-400 font-medium">Ученик</div>
                  <div className="text-base sm:text-lg font-bold text-slate-800 mt-0.5">
                    {lesson.student?.name || 'Без имени'}
                  </div>
                  {lesson.student?.phone && (
                    <div className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      <span>{lesson.student.phone}</span>
                    </div>
                  )}
                </div>
                <div
                  className={`px-3 py-1 rounded-full text-xs font-semibold border ${statusInfo.badgeClass}`}
                >
                  {statusInfo.label}
                </div>
              </div>

              {isRecurring && (
                <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center gap-2 text-xs text-slate-600">
                  <Repeat className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    Повторяющийся урок {lesson.is_exception ? '(с индивидуальными изменениями)' : ''}
                  </span>
                </div>
              )}
            </div>

            {/* Время и дата */}
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                <div className="text-xs text-slate-400 flex items-center gap-1 mb-1">
                  <CalendarIcon className="w-3.5 h-3.5" />
                  <span>Дата</span>
                </div>
                <div className="font-semibold text-slate-800">
                  {formatDateFull(lesson.date)}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                <div className="text-xs text-slate-400 flex items-center gap-1 mb-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Время и длительность</span>
                </div>
                <div className="font-semibold text-slate-800">
                  {formatTime(lesson.start_time)} – {endTime}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {lesson.duration_minutes} минут
                </div>
              </div>
            </div>

            {/* Заметка */}
            {lesson.note && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60 text-xs">
                <div className="text-slate-400 font-semibold mb-1 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5" />
                  <span>Заметка к уроку:</span>
                </div>
                <div className="text-slate-700 whitespace-pre-wrap">{lesson.note}</div>
              </div>
            )}

            {/* Быстрые действия со статусом */}
            <div>
              <div className="text-xs font-semibold text-slate-600 mb-2">Изменить статус:</div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => handleStatusChange('scheduled')}
                  disabled={isSubmitting || lesson.status === 'scheduled'}
                  className={`py-2 px-2 text-xs font-medium rounded-xl border transition ${
                    lesson.status === 'scheduled'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold'
                      : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  Запланирован
                </button>
                <button
                  type="button"
                  onClick={() => handleStatusChange('completed')}
                  disabled={isSubmitting || lesson.status === 'completed'}
                  className={`py-2 px-2 text-xs font-medium rounded-xl border transition ${
                    lesson.status === 'completed'
                      ? 'bg-slate-200 text-slate-800 border-slate-300 font-bold'
                      : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  Проведён
                </button>
                <button
                  type="button"
                  onClick={() => handleStatusChange('cancelled')}
                  disabled={isSubmitting || lesson.status === 'cancelled'}
                  className={`py-2 px-2 text-xs font-medium rounded-xl border transition ${
                    lesson.status === 'cancelled'
                      ? 'bg-rose-50 text-rose-700 border-rose-300 font-bold'
                      : 'bg-white hover:bg-slate-50 text-rose-600 border-slate-200'
                  }`}
                >
                  Отменён
                </button>
              </div>
            </div>

            {/* Подтверждения удаления */}
            {confirmDeleteOpen && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl space-y-3">
                <div className="text-xs font-semibold text-rose-800">
                  {lesson.status === 'completed'
                    ? 'Проведённый урок нельзя удалить: он останется в истории.'
                    : 'Удалить этот урок из расписания?'}
                </div>
                <div className="flex gap-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteOpen(false)}
                    className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium"
                  >
                    Отмена
                  </button>
                  <button
                    type="button"
                    onClick={handleDeleteSingle}
                    disabled={isSubmitting || lesson.status === 'completed'}
                    className="px-3 py-1.5 text-xs bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-semibold"
                  >
                    Да, удалить урок
                  </button>
                </div>
              </div>
            )}

            {deleteSeriesOpen && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl space-y-3">
                <div className="text-xs font-semibold text-rose-800">
                  Завершить серию? Будущие запланированные уроки будут удалены, проведённые занятия останутся в истории.
                </div>
                <div className="flex gap-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setDeleteSeriesOpen(false)}
                    className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium"
                  >
                    Отмена
                  </button>
                  <button
                    type="button"
                    onClick={handleDeleteWholeSeries}
                    disabled={isSubmitting}
                    className="px-3 py-1.5 text-xs bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-semibold"
                  >
                    Завершить серию
                  </button>
                </div>
              </div>
            )}

            {/* Нижняя панель действий */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                {!confirmDeleteOpen && !deleteSeriesOpen && (
                  <>
                    {lesson.status === 'completed' ? (
                      <span className="px-2 py-2 text-xs text-slate-500">
                        Проведённый урок сохранён в истории
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteOpen(true)}
                        className="px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 rounded-xl font-medium transition flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Удалить урок</span>
                      </button>
                    )}

                    {isRecurring && (
                      <button
                        type="button"
                        onClick={() => setDeleteSeriesOpen(true)}
                        className="px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 rounded-xl font-medium transition flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Удалить серию</span>
                      </button>
                    )}
                  </>
                )}
              </div>

              <button
                type="button"
                onClick={() => setIsEditing(true)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition flex items-center gap-1.5 ml-auto"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Редактировать</span>
              </button>
            </div>
          </div>
        )}

        {/* Режим редактирования */}
        {isEditing && (
          <form onSubmit={handleSaveEdit} className="mt-4 space-y-4">
            <div className="text-xs font-semibold text-slate-700">
              Ученик: <span className="font-bold text-slate-900">{lesson.student?.name}</span>
            </div>

            {/* Дата и время */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Дата</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={(e) => setEditDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Время начала
                </label>
                <input
                  type="time"
                  value={editTime}
                  onChange={(e) => setEditTime(e.target.value)}
                  step="300"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>
            </div>

            {/* Длительность */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-700">Длительность</label>
                <span className="text-xs text-slate-500">
                  Завершение: <b className="text-slate-800">{editEndTime}</b>
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {DURATION_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setEditDuration(opt.value)}
                    className={`py-2 text-xs font-medium rounded-xl border transition ${
                      editDuration === opt.value
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    {opt.value} мин
                  </button>
                ))}
              </div>
            </div>

            {/* Конфликт времени */}
            {conflictWarning && (
              <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-800 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>{conflictWarning}</span>
              </div>
            )}
            {editValidationWarning && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
                {editValidationWarning}
              </div>
            )}

            {/* Если это серия, спрашиваем масштаб изменений */}
            {isRecurring && (
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <label className="block text-xs font-bold text-slate-800">
                  Применить изменения:
                </label>
                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700">
                    <input
                      type="radio"
                      name="recurrenceScope"
                      value="single"
                      checked={recurrenceScope === 'single'}
                      onChange={() => setRecurrenceScope('single')}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Только для этого занятия ({formatDateReadable(editDate)})</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700">
                    <input
                      type="radio"
                      name="recurrenceScope"
                      value="future"
                      checked={recurrenceScope === 'future'}
                      onChange={() => setRecurrenceScope('future')}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Для этого и всех последующих уроков серии</span>
                  </label>
                </div>
              </div>
            )}

            {/* Заметка */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Заметка</label>
              <textarea
                rows={2}
                value={editNote}
                onChange={(e) => setEditNote(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
              />
            </div>

            {/* Кнопки формы */}
            <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                disabled={isSubmitting}
                className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 disabled:opacity-50"
              >
                Назад
              </button>
              <button
                type="submit"
                disabled={
                  isSubmitting ||
                  Boolean(conflictWarning) ||
                  Boolean(editValidationWarning)
                }
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-semibold rounded-xl shadow-xs transition flex items-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Сохранение...
                  </>
                ) : (
                  'Сохранить изменения'
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
