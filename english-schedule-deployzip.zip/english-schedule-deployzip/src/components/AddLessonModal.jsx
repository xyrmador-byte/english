import React, { useState, useEffect } from 'react';
import {
  X,
  Clock,
  Calendar as CalendarIcon,
  User,
  Repeat,
  AlertTriangle,
  Loader2,
  Plus,
  FileText,
} from 'lucide-react';
import { DURATION_OPTIONS, WEEKDAYS } from '../lib/types';
import {
  formatDateFull,
  formatTime,
  addMinutesToTime,
  getWeekdayNumber,
  getTodayIso,
  parseISO,
  timeToMinutes,
} from '../lib/dateUtils';
import { getSupabase } from '../lib/supabase';
import { findScheduleConflicts } from '../lib/schedule';

export default function AddLessonModal({
  isOpen,
  onClose,
  initialDate,
  initialTime,
  initialStudentId,
  students = [],
  existingLessons = [],
  existingRules = [],
  timezone,
  onLessonCreated,
  onStudentCreated,
  showToast,
}) {
  const [studentId, setStudentId] = useState('');
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('10:00');
  const [duration, setDuration] = useState(60);
  const [note, setNote] = useState('');

  // Inline создание нового ученика
  const [isCreatingStudent, setIsCreatingStudent] = useState(false);
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentPhone, setNewStudentPhone] = useState('');

  // Повторение
  const [recurrenceType, setRecurrenceType] = useState('none'); // 'none', 'daily', 'weekly_single', 'weekly_multiple'
  const [selectedWeekdays, setSelectedWeekdays] = useState([]); // [1, 2, 4]
  const [untilDate, setUntilDate] = useState('');
  const [hasEndDate, setHasEndDate] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Инициализация полей при открытии
  useEffect(() => {
    if (isOpen) {
      const todayIso = getTodayIso(timezone);
      setDate(initialDate || todayIso);
      setStartTime(initialTime ? formatTime(initialTime) : '10:00');
      setDuration(60);
      setNote('');
      setIsCreatingStudent(false);
      setNewStudentName('');
      setNewStudentPhone('');
      setRecurrenceType('none');
      setHasEndDate(false);
      setUntilDate('');

      if (initialStudentId) {
        setStudentId(initialStudentId);
      } else if (students.length > 0) {
        // Выбираем первого активного
        const activeOne = students.find((s) => s.status === 'active');
        setStudentId(activeOne ? activeOne.id : students[0].id);
      } else {
        setStudentId('');
      }

      // День недели для weekly_single
      const targetDate = parseISO(initialDate || todayIso);
      setSelectedWeekdays([getWeekdayNumber(targetDate)]);
    }
  }, [isOpen, initialDate, initialTime, initialStudentId, students, timezone]);

  const recurrenceFrequency = recurrenceType === 'daily' ? 'daily' : 'weekly';
  const recurrenceWeekdays =
    recurrenceType === 'daily'
      ? [1, 2, 3, 4, 5, 6, 7]
      : recurrenceType === 'weekly_multiple'
        ? selectedWeekdays
        : date
          ? [getWeekdayNumber(date)]
          : [];
  const candidate = {
    ...(recurrenceType === 'none'
      ? { date }
      : {
          freq: recurrenceFrequency,
          start_date: date,
          until_date: hasEndDate ? untilDate : null,
          by_weekdays: recurrenceWeekdays,
        }),
    start_time: formatTime(startTime),
    duration_minutes: Number(duration),
  };
  const conflicts = findScheduleConflicts({
    candidate,
    existingLessons,
    existingRules,
  });
  const conflictWarning = conflicts.length
    ? `Пересечение ${formatDateFull(conflicts[0].date)}: занятие с «${conflicts[0].student_name}» (${formatTime(conflicts[0].start_time)}–${conflicts[0].end_time}).`
    : null;
  const invalidTime = timeToMinutes(startTime) + Number(duration) > 24 * 60;
  const invalidEndDate =
    recurrenceType !== 'none' &&
    hasEndDate &&
    (!untilDate || untilDate < date);
  const validationWarning = invalidTime
    ? 'Урок должен завершаться до полуночи.'
    : invalidEndDate
      ? 'Дата окончания серии должна быть не раньше начала.'
      : null;

  if (!isOpen) return null;

  const toggleWeekday = (dayId) => {
    if (selectedWeekdays.includes(dayId)) {
      if (selectedWeekdays.length > 1) {
        setSelectedWeekdays(selectedWeekdays.filter((d) => d !== dayId));
      }
    } else {
      setSelectedWeekdays([...selectedWeekdays, dayId].sort());
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (invalidTime) {
      showToast({ type: 'warning', message: 'Урок должен завершаться до полуночи.' });
      return;
    }
    if (invalidEndDate) {
      showToast({ type: 'warning', message: 'Дата окончания серии должна быть не раньше начала.' });
      return;
    }
    if (conflicts.length) {
      showToast({
        type: 'error',
        title: 'В расписании уже есть урок',
        message: conflictWarning,
      });
      return;
    }

    const supabase = getSupabase();
    if (!supabase) {
      showToast({ type: 'error', message: 'База данных не подключена' });
      return;
    }

    setIsSubmitting(true);
    try {
      let finalStudentId = studentId;

      // 1. Если создаём ученика прямо здесь
      if (isCreatingStudent) {
        if (!newStudentName.trim()) {
          throw new Error('Укажите имя нового ученика');
        }

        const {
          data: { user },
        } = await supabase.auth.getUser();
        if (!user) throw new Error('Пользователь не авторизован');

        const { data: newStudent, error: createStudentErr } = await supabase
          .from('students')
          .insert({
            teacher_id: user.id,
            name: newStudentName.trim(),
            phone: newStudentPhone.trim(),
            status: 'active',
          })
          .select()
          .single();

        if (createStudentErr) throw createStudentErr;
        finalStudentId = newStudent.id;
        if (onStudentCreated) onStudentCreated(newStudent);
      }

      if (!finalStudentId) {
        throw new Error('Выберите ученика или создайте нового');
      }
      const selectedStudent = students.find((student) => student.id === finalStudentId);
      if (!isCreatingStudent && selectedStudent?.status !== 'active') {
        throw new Error('Нельзя записать на новый урок архивного ученика');
      }

      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error('Пользователь не авторизован');

      const cleanStartTime = formatTime(startTime) + ':00';

      // 2. Обычный разовый урок
      if (recurrenceType === 'none') {
        const { error: insertLessonErr } = await supabase.from('lessons').insert({
          teacher_id: user.id,
          student_id: finalStudentId,
          date: date,
          start_time: cleanStartTime,
          duration_minutes: duration,
          note: note.trim(),
          status: 'scheduled',
          is_exception: false,
        });

        if (insertLessonErr) throw insertLessonErr;

        showToast({
          type: 'success',
          title: 'Урок добавлен',
          message: `Занятие на ${date} успешно сохранено`,
        });
      } else {
        // 3. Повторяющийся урок (создаем recurrence_rule)
        let freq = 'weekly';
        let byWeekdays = [];

        if (recurrenceType === 'daily') {
          freq = 'daily';
          byWeekdays = [1, 2, 3, 4, 5, 6, 7];
        } else if (recurrenceType === 'weekly_single') {
          freq = 'weekly';
          byWeekdays = [getWeekdayNumber(date)];
        } else if (recurrenceType === 'weekly_multiple') {
          freq = 'weekly';
          byWeekdays = selectedWeekdays.length > 0 ? selectedWeekdays : [getWeekdayNumber(date)];
        }

        const rulePayload = {
          teacher_id: user.id,
          student_id: finalStudentId,
          freq: freq,
          by_weekdays: byWeekdays,
          start_date: date,
          start_time: cleanStartTime,
          duration_minutes: duration,
          until_date: hasEndDate && untilDate ? untilDate : null,
          note: note.trim(),
        };

        const { error: insertRuleErr } = await supabase
          .from('recurrence_rules')
          .insert(rulePayload);

        if (insertRuleErr) throw insertRuleErr;

        showToast({
          type: 'success',
          title: 'Серия уроков создана',
          message: 'Повторяющиеся уроки добавлены в расписание',
        });
      }

      onLessonCreated();
      onClose();
    } catch (err) {
      showToast({
        type: 'error',
        title: 'Ошибка сохранения',
        message: err.message || 'Не удалось сохранить урок в базе данных',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const calculatedEndTime = addMinutesToTime(startTime, duration);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full my-6 p-5 sm:p-7 border border-slate-100 transition-all max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-800">Добавить урок</h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="mt-4 space-y-4">
          {/* Ученик */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700">Ученик *</label>
              <button
                type="button"
                onClick={() => setIsCreatingStudent(!isCreatingStudent)}
                className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1 hover:underline"
              >
                {isCreatingStudent ? 'Выбрать из списка' : '+ Новый ученик'}
              </button>
            </div>

            {isCreatingStudent ? (
              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200/80 space-y-2">
                <input
                  type="text"
                  placeholder="Имя и фамилия ученика"
                  value={newStudentName}
                  onChange={(e) => setNewStudentName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
                <input
                  type="tel"
                  placeholder="Телефон / мессенджер (необязательно)"
                  value={newStudentPhone}
                  onChange={(e) => setNewStudentPhone(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            ) : (
              <div className="relative">
                <select
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  className="w-full px-3 py-2.5 text-sm rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                >
                  {students.filter((s) => s.status === 'active').length === 0 ? (
                    <option value="">Нет активных учеников (создайте ученика)</option>
                  ) : (
                    students
                      .filter((s) => s.status === 'active')
                      .map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} {s.phone ? `(${s.phone})` : ''}
                        </option>
                      ))
                  )}
                </select>
              </div>
            )}
          </div>

          {/* Дата и Время */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Дата *</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Время начала *
              </label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                step="300"
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
          </div>

          {/* Длительность */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700">Длительность</label>
              <span className="text-xs text-slate-500">
                Завершение: <b className="text-slate-800">{calculatedEndTime}</b>
              </span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {DURATION_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setDuration(opt.value)}
                  className={`py-2 text-xs font-medium rounded-xl border transition ${
                    duration === opt.value
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  {opt.value} мин
                </button>
              ))}
            </div>
          </div>

          {/* Предупреждение о конфликте времени */}
          {conflictWarning && (
            <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-800 text-xs flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>{conflictWarning}</span>
            </div>
          )}
          {validationWarning && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
              {validationWarning}
            </div>
          )}

          {/* Повторение */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center gap-2">
              <Repeat className="w-4 h-4 text-emerald-600" />
              <label className="text-xs font-bold text-slate-800">Повторение урока</label>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setRecurrenceType('none')}
                className={`py-2 px-2.5 rounded-lg border text-left transition ${
                  recurrenceType === 'none'
                    ? 'bg-white border-emerald-500 text-emerald-800 font-semibold shadow-2xs'
                    : 'bg-white/60 border-slate-200 text-slate-600'
                }`}
              >
                Однократно (без повторения)
              </button>
              <button
                type="button"
                onClick={() => setRecurrenceType('daily')}
                className={`py-2 px-2.5 rounded-lg border text-left transition ${
                  recurrenceType === 'daily'
                    ? 'bg-white border-emerald-500 text-emerald-800 font-semibold shadow-2xs'
                    : 'bg-white/60 border-slate-200 text-slate-600'
                }`}
              >
                Каждый день
              </button>
              <button
                type="button"
                onClick={() => {
                  setRecurrenceType('weekly_single');
                  setSelectedWeekdays([getWeekdayNumber(date)]);
                }}
                className={`py-2 px-2.5 rounded-lg border text-left transition ${
                  recurrenceType === 'weekly_single'
                    ? 'bg-white border-emerald-500 text-emerald-800 font-semibold shadow-2xs'
                    : 'bg-white/60 border-slate-200 text-slate-600'
                }`}
              >
                Каждую неделю в этот день
              </button>
              <button
                type="button"
                onClick={() => {
                  setRecurrenceType('weekly_multiple');
                  if (selectedWeekdays.length === 0) {
                    setSelectedWeekdays([getWeekdayNumber(date)]);
                  }
                }}
                className={`py-2 px-2.5 rounded-lg border text-left transition ${
                  recurrenceType === 'weekly_multiple'
                    ? 'bg-white border-emerald-500 text-emerald-800 font-semibold shadow-2xs'
                    : 'bg-white/60 border-slate-200 text-slate-600'
                }`}
              >
                В выбранные дни недели
              </button>
            </div>

            {/* Выбор дней недели при 'weekly_multiple' */}
            {recurrenceType === 'weekly_multiple' && (
              <div className="pt-2">
                <span className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                  Выберите дни повторения:
                </span>
                <div className="flex gap-1.5 justify-between">
                  {WEEKDAYS.map((wd) => {
                    const isSelected = selectedWeekdays.includes(wd.id);
                    return (
                      <button
                        key={wd.id}
                        type="button"
                        onClick={() => toggleWeekday(wd.id)}
                        className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition ${
                          isSelected
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {wd.short}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Дата окончания повторения */}
            {recurrenceType !== 'none' && (
              <div className="pt-2 border-t border-slate-200/60">
                <label className="flex items-center gap-2 cursor-pointer mb-2">
                  <input
                    type="checkbox"
                    checked={hasEndDate}
                    onChange={(e) => setHasEndDate(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <span className="text-xs text-slate-700">Задать дату окончания серии</span>
                </label>

                {hasEndDate && (
                  <input
                    type="date"
                    min={date}
                    value={untilDate}
                    onChange={(e) => setUntilDate(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Дата завершения повторений"
                    required={hasEndDate}
                  />
                )}
              </div>
            )}
          </div>

          {/* Заметка к уроку */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Заметка (необязательно)
            </label>
            <textarea
              rows={2}
              placeholder="Тема урока, страница учебника, ссылка на Zoom..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
            />
          </div>

          {/* Кнопки */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 transition"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={
                isSubmitting ||
                Boolean(conflictWarning) ||
                invalidTime ||
                invalidEndDate
              }
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-semibold rounded-xl shadow-xs hover:shadow transition flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Сохранение...
                </>
              ) : (
                'Сохранить урок'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
