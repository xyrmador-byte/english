import React, { useState } from 'react';
import { Lock, Mail, User, LogIn, UserPlus, AlertCircle, Loader2 } from 'lucide-react';
import { getSupabase } from '../lib/supabase';

export default function AuthModal({ onAuthSuccess, onOpenDbConfig }) {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const supabase = getSupabase();
    if (!supabase) {
      setError('База данных Supabase не настроена. Нажмите "Настроить подключение" ниже.');
      return;
    }

    setIsLoading(true);
    try {
      if (isRegister) {
        // Регистрация аккаунта преподавателя
        const { data, error: signUpError } = await supabase.auth.signUp({
          email: email.trim(),
          password: password,
          options: {
            data: {
              full_name: fullName.trim() || 'Преподаватель',
            },
          },
        });

        if (signUpError) throw signUpError;

        if (data?.session) {
          onAuthSuccess(data.session.user);
        } else if (data?.user && !data.session) {
          setError('Аккаунт создан! Если в настройках Supabase включено подтверждение email, проверьте входящие письма, либо отключите Confirm email в Supabase Authentication -> Providers -> Email.');
        }
      } else {
        // Вход преподавателя
        const { data, error: signInError } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password: password,
        });

        if (signInError) {
          if (signInError.message.includes('Invalid login credentials')) {
            throw new Error('Неверный email или пароль');
          }
          throw signInError;
        }

        if (data?.session) {
          onAuthSuccess(data.session.user);
        }
      }
    } catch (err) {
      setError(err.message || 'Ошибка авторизации');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 sm:p-8 border border-slate-100">
        <div className="text-center mb-6">
          <div className="inline-flex p-3 bg-emerald-100 text-emerald-700 rounded-2xl mb-3 shadow-inner">
            <Lock className="w-7 h-7" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">
            Ежедневник преподавателя
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isRegister ? 'Создание персонального аккаунта преподавателя' : 'Вход в личное расписание занятий'}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Ваше имя / Обращение:
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="Анна Сергеевна"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required={isRegister}
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Электронная почта (Email):
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="email"
                placeholder="teacher@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Пароль:
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="password"
                placeholder="Минимум 6 символов"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={6}
                className="w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-medium rounded-xl shadow-md transition flex items-center justify-center gap-2 text-sm"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                {isRegister ? 'Регистрация...' : 'Вход...'}
              </>
            ) : isRegister ? (
              <>
                <UserPlus className="w-4 h-4" />
                Создать аккаунт
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                Войти в расписание
              </>
            )}
          </button>
        </form>

        <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col items-center gap-2 text-xs text-slate-500">
          <button
            type="button"
            onClick={() => {
              setIsRegister(!isRegister);
              setError('');
            }}
            className="text-emerald-700 hover:text-emerald-800 font-medium hover:underline"
          >
            {isRegister
              ? 'Уже есть аккаунт? Войти'
              : 'Первый раз здесь? Создать аккаунт преподавателя'}
          </button>

          {onOpenDbConfig && (
            <button
              type="button"
              onClick={onOpenDbConfig}
              className="text-slate-400 hover:text-slate-600 transition underline text-[11px] mt-1"
            >
              Настроить подключение к Supabase
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
