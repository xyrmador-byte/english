import React, { useState } from 'react';
import { Database, Key, ExternalLink, Check, AlertCircle, Loader2 } from 'lucide-react';
import { getSupabaseConfig, setSupabaseConfig, testSupabaseConnection } from '../lib/supabase';

export default function DbSetupModal({ isOpen, onClose, onConfigSaved, isMandatory = false }) {
  const currentConfig = getSupabaseConfig();
  const [url, setUrl] = useState(currentConfig.url || '');
  const [anonKey, setAnonKey] = useState(currentConfig.anonKey || '');
  const [isTesting, setIsTesting] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    const cleanUrl = url.trim();
    const cleanKey = anonKey.trim();

    if (!cleanUrl || !cleanKey) {
      setError('Пожалуйста, заполните оба поля: URL проекта и Anon-ключ.');
      return;
    }

    if (!cleanUrl.startsWith('https://')) {
      setError('URL проекта должен начинаться с https://');
      return;
    }

    setIsTesting(true);
    try {
      const testResult = await testSupabaseConnection(cleanUrl, cleanKey);
      if (!testResult.success) {
        setError(`Ошибка подключения: ${testResult.error}. Проверьте правильность URL и ключа.`);
        setIsTesting(false);
        return;
      }

      setSupabaseConfig({ url: cleanUrl, anonKey: cleanKey });
      setSuccessMsg('Подключение к Supabase успешно установлено!');
      setTimeout(() => {
        if (onConfigSaved) onConfigSaved();
        if (onClose) onClose();
      }, 700);
    } catch (err) {
      setError(err.message || 'Не удалось установить соединение');
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 sm:p-8 border border-slate-100">
        <div className="flex items-center gap-3 mb-5">
          <div className="p-3 bg-emerald-100 text-emerald-700 rounded-xl">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800">
              Подключение базы данных Supabase
            </h2>
            <p className="text-xs text-slate-500">
              Настраивается один раз для сохранения расписания в облаке
            </p>
          </div>
        </div>

        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs text-slate-600 mb-5 leading-relaxed">
          <p className="font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            💡 Где взять эти параметры?
          </p>
          В вашем аккаунте{' '}
          <a
            href="https://supabase.com/dashboard"
            target="_blank"
            rel="noopener noreferrer"
            className="text-emerald-600 underline font-medium inline-flex items-center gap-0.5"
          >
            Supabase Dashboard <ExternalLink className="w-3 h-3" />
          </a>
          : откройте проект &rarr; <b>Project Settings</b> &rarr; <b>API</b> &rarr; скопируйте <b>Project URL</b> и <b>Project API keys (anon public)</b>.
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Project URL (Адрес проекта):
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="https://xyzcompany.supabase.co"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-xs"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Anon Public Key (Публичный анонимный ключ):
            </label>
            <div className="relative">
              <textarea
                rows={3}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                value={anonKey}
                onChange={(e) => setAnonKey(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono resize-none"
                required
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Используйте только anon public ключ. Никогда не вводите service_role ключ.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            {!isMandatory && (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-800 transition"
              >
                Отмена
              </button>
            )}
            <button
              type="submit"
              disabled={isTesting}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-medium rounded-xl shadow transition flex items-center gap-2"
            >
              {isTesting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Проверка подключения...
                </>
              ) : (
                'Подключить базу'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
