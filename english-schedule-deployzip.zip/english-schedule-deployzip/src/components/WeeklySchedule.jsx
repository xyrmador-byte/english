import React, { useState } from 'react';
import {
  formatDateIso,
  formatDateReadable,
  formatTime,
  addMinutesToTime,
  isDateToday,
  getWeekdayNumber,
} from '../lib/dateUtils';
import { STATUS_CONFIG, WEEKDAYS } from '../lib/types';
import { Clock, Plus, Repeat, Calendar as CalendarIcon, User } from 'lucide-react';

const HOURS = Array.from({ length: 14 }).map((_, i) => i + 8); // 8:00 to 21:00

export default function WeeklySchedule({
  weekDays,
  lessons = [],
  timezone,
  onSelectLesson,
  onAddLessonAtTime,
}) {
  // Выбранный день для мобильного экрана (по умолчанию сегодня, если входит в неделю, иначе Пн)
  const todayMondayIndex = weekDays.findIndex((d) => isDateToday(d, timezone));
  const [mobileSelectedDayIndex, setMobileSelectedDayIndex] = useState(
    todayMondayIndex >= 0 ? todayMondayIndex : 0
  );

  const mobileDay = weekDays[mobileSelectedDayIndex] || weekDays[0];
  const mobileDayIso = formatDateIso(mobileDay);

  // Группировка уроков по датам
  const lessonsByDate = {};
  weekDays.forEach((d) => {
    lessonsByDate[formatDateIso(d)] = [];
  });

  lessons.forEach((l) => {
    if (lessonsByDate[l.date]) {
      lessonsByDate[l.date].push(l);
    }
  });

  // Сортировка уроков по времени
  Object.keys(lessonsByDate).forEach((dateKey) => {
    lessonsByDate[dateKey].sort((a, b) => a.start_time.localeCompare(b.start_time));
  });

  return (
    <div className="w-full">
      {/* ======================================================== */}
      {/* 1. МОБИЛЬНЫЙ ВИД (1 день за раз с переключателем дней)     */}
      {/* ======================================================== */}
      <div className="block lg:hidden">
        {/* Переключатель дней недели */}
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200/80 p-2 mb-4">
          <div className="grid grid-cols-7 gap-1">
            {weekDays.map((d, index) => {
              const dIso = formatDateIso(d);
              const dayLessons = lessonsByDate[dIso] || [];
              const isSelected = index === mobileSelectedDayIndex;
              const isCurrentToday = isDateToday(d, timezone);
              const weekday = WEEKDAYS[index];

              return (
                <button
                  key={dIso}
                  onClick={() => setMobileSelectedDayIndex(index)}
                  className={`flex flex-col items-center py-2 px-1 rounded-xl transition text-center relative ${
                    isSelected
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'hover:bg-slate-100 text-slate-700'
                  }`}
                >
                  <span
                    className={`text-[10px] font-semibold uppercase ${
                      isSelected ? 'text-emerald-100' : 'text-slate-400'
                    }`}
                  >
                    {weekday.short}
                  </span>
                  <span
                    className={`text-sm font-bold mt-0.5 ${
                      isCurrentToday && !isSelected ? 'text-emerald-600 underline' : ''
                    }`}
                  >
                    {d.getDate()}
                  </span>
                  {dayLessons.length > 0 && (
                    <span
                      className={`w-1.5 h-1.5 rounded-full mt-1 ${
                        isSelected ? 'bg-white' : 'bg-emerald-500'
                      }`}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Список уроков выбранного дня */}
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200/80 p-4">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
            <div>
              <div className="text-xs text-slate-400 font-medium uppercase tracking-wider">
                {WEEKDAYS[mobileSelectedDayIndex]?.full}
              </div>
              <div className="text-base font-bold text-slate-800">
                {formatDateReadable(mobileDay)}
              </div>
            </div>
            <button
              onClick={() => onAddLessonAtTime(mobileDayIso, '10:00')}
              className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold text-xs rounded-xl border border-emerald-200 flex items-center gap-1 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Добавить</span>
            </button>
          </div>

          {/* Список карточек дня */}
          {lessonsByDate[mobileDayIso]?.length === 0 ? (
            <div className="text-center py-10 px-4">
              <CalendarIcon className="w-10 h-10 text-slate-300 mx-auto mb-2.5" />
              <div className="text-sm font-semibold text-slate-700">Нет уроков в этот день</div>
              <p className="text-xs text-slate-400 mt-1 mb-4">Время свободно для новых занятий</p>
              <button
                onClick={() => onAddLessonAtTime(mobileDayIso, '10:00')}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition"
              >
                <Plus className="w-4 h-4" />
                <span>Записать ученика</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {lessonsByDate[mobileDayIso].map((l) => {
                const statusInfo = STATUS_CONFIG[l.status] || STATUS_CONFIG.scheduled;
                const endTime = addMinutesToTime(l.start_time, l.duration_minutes);

                return (
                  <div
                    key={l.id}
                    onClick={() => onSelectLesson(l)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition shadow-2xs hover:shadow-xs ${statusInfo.cardBorder}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="font-bold text-slate-800 text-sm sm:text-base">
                        {l.student?.name || 'Ученик'}
                      </div>
                      <div
                        className={`px-2 py-0.5 rounded-md text-[11px] font-semibold border ${statusInfo.badgeClass}`}
                      >
                        {statusInfo.label}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mt-2 text-xs text-slate-600 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>
                        {formatTime(l.start_time)} – {endTime}
                      </span>
                      <span className="text-slate-300">•</span>
                      <span className="text-slate-500">{l.duration_minutes} мин</span>

                      {l.is_recurring && (
                        <span className="ml-auto flex items-center gap-1 text-[11px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                          <Repeat className="w-3 h-3" />
                          <span>Серия</span>
                        </span>
                      )}
                    </div>

                    {l.note && (
                      <div className="mt-2 text-xs text-slate-500 bg-slate-50 p-2 rounded-lg truncate">
                        {l.note}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ======================================================== */}
      {/* 2. ДЕСКТОПНЫЙ И ПЛАНШЕТНЫЙ ВИД (Недельная сетка 7 колонок) */}
      {/* ======================================================== */}
      <div className="hidden lg:block bg-white rounded-2xl shadow-xs border border-slate-200/80 overflow-hidden">
        {/* Заголовки дней недели */}
        <div className="grid grid-cols-8 border-b border-slate-200/80 bg-slate-50/70">
          {/* Пустая ячейка над шкалой времени */}
          <div className="p-3 text-center border-r border-slate-200/80 text-xs font-semibold text-slate-400">
            Время
          </div>

          {/* Колонки дней */}
          {weekDays.map((d, index) => {
            const isCurrentToday = isDateToday(d, timezone);
            const weekday = WEEKDAYS[index];

            return (
              <div
                key={formatDateIso(d)}
                className={`p-3 text-center border-r border-slate-200/80 last:border-r-0 ${
                  isCurrentToday ? 'bg-emerald-50/70' : ''
                }`}
              >
                <div
                  className={`text-xs font-bold uppercase tracking-wider ${
                    isCurrentToday ? 'text-emerald-700' : 'text-slate-500'
                  }`}
                >
                  {weekday.short}
                </div>
                <div
                  className={`text-base font-extrabold mt-0.5 ${
                    isCurrentToday ? 'text-emerald-800' : 'text-slate-800'
                  }`}
                >
                  {d.getDate()}{' '}
                  <span className="text-xs font-normal text-slate-400">
                    {formatDateReadable(d).split(' ')[1]}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Тело расписания: сетка часов */}
        <div className="divide-y divide-slate-100">
          {HOURS.map((hour) => {
            const hourStr = `${String(hour).padStart(2, '0')}:00`;

            return (
              <div key={hour} className="grid grid-cols-8 min-h-[72px]">
                {/* Метка часа */}
                <div className="p-2 text-right pr-3 border-r border-slate-200/80 text-xs font-medium text-slate-400 select-none bg-slate-50/30">
                  {hourStr}
                </div>

                {/* 7 колонок дней */}
                {weekDays.map((d) => {
                  const dayIso = formatDateIso(d);
                  const isCurrentToday = isDateToday(d, timezone);
                  const dayLessons = lessonsByDate[dayIso] || [];

                  // Ищем уроки, которые начинаются в этом часу (например 10:00 - 10:59)
                  const slotLessons = dayLessons.filter((l) => {
                    const startH = parseInt(l.start_time.split(':')[0], 10);
                    return startH === hour;
                  });

                  return (
                    <div
                      key={dayIso}
                      className={`relative border-r border-slate-200/80 last:border-r-0 p-1 group transition-colors ${
                        isCurrentToday ? 'bg-emerald-50/20' : ''
                      } hover:bg-slate-50/70`}
                    >
                      {/* Если в этом часе есть уроки */}
                      {slotLessons.length > 0 ? (
                        <div className="space-y-1">
                          {slotLessons.map((l) => {
                            const statusInfo = STATUS_CONFIG[l.status] || STATUS_CONFIG.scheduled;
                            const endTime = addMinutesToTime(l.start_time, l.duration_minutes);

                            return (
                              <div
                                key={l.id}
                                onClick={() => onSelectLesson(l)}
                                className={`p-2 rounded-xl border cursor-pointer transition shadow-2xs hover:shadow-md hover:scale-[1.01] ${statusInfo.cardBorder}`}
                              >
                                <div className="flex items-center justify-between gap-1">
                                  <div className="font-bold text-slate-800 text-xs truncate">
                                    {l.student?.name || 'Ученик'}
                                  </div>
                                  {l.is_recurring && (
                                    <Repeat
                                      className="w-3 h-3 text-emerald-600 shrink-0"
                                      title="Повторяющийся урок"
                                    />
                                  )}
                                </div>

                                <div className="text-[11px] font-semibold text-slate-600 mt-1 flex items-center justify-between">
                                  <span>
                                    {formatTime(l.start_time)} – {endTime}
                                  </span>
                                  <span className="text-[10px] text-slate-400">
                                    {l.duration_minutes}м
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        /* Свободный временной слот: кнопка быстрого добавления */
                        <button
                          onClick={() => onAddLessonAtTime(dayIso, hourStr)}
                          className="w-full h-full min-h-[64px] rounded-lg opacity-0 group-hover:opacity-100 flex items-center justify-center text-slate-400 hover:text-emerald-700 hover:bg-emerald-50/50 transition border border-dashed border-transparent hover:border-emerald-300"
                          title={`Добавить урок на ${formatDateReadable(d)} в ${hourStr}`}
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
