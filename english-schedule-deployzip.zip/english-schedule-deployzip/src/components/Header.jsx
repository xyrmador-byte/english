import React from 'react';
import {
  Calendar as CalendarIcon,
  Users,
  Settings,
  ChevronLeft,
  ChevronRight,
  Plus,
  CalendarCheck2,
} from 'lucide-react';
import { formatWeekRange } from '../lib/dateUtils';

export default function Header({
  activeTab,
  setActiveTab,
  weekDays,
  onPrevWeek,
  onNextWeek,
  onToday,
  onOpenAddLesson,
}) {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        {/* Top row: Brand + Main Nav + Add Lesson */}
        <div className="flex items-center justify-between h-16 gap-2">
          {/* Brand */}
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-sm shadow-emerald-200">
              <CalendarCheck2 className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-slate-800 text-base sm:text-lg leading-tight tracking-tight">
                English Schedule
              </div>
              <div className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Ежедневник преподавателя
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center bg-slate-100/90 p-1 rounded-xl border border-slate-200/60">
            <button
              onClick={() => setActiveTab('schedule')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition ${
                activeTab === 'schedule'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CalendarIcon className="w-4 h-4" />
              <span>Расписание</span>
            </button>

            <button
              onClick={() => setActiveTab('students')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition ${
                activeTab === 'students'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Ученики</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition ${
                activeTab === 'settings'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Настройки</span>
            </button>
          </nav>

          {/* "+ Добавить урок" button */}
          <button
            onClick={onOpenAddLesson}
            className="flex items-center gap-1.5 px-3.5 sm:px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs hover:shadow transition font-medium text-xs sm:text-sm shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden xs:inline sm:inline">Добавить урок</span>
            <span className="xs:hidden sm:hidden">Урок</span>
          </button>
        </div>

        {/* Sub-bar: Calendar Navigation (only visible when in 'schedule' tab) */}
        {activeTab === 'schedule' && (
          <div className="py-2.5 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-1 sm:gap-2">
              <button
                onClick={onToday}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition"
              >
                Сегодня
              </button>
              <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200/60">
                <button
                  onClick={onPrevWeek}
                  className="p-1 hover:bg-white hover:text-slate-800 rounded-md text-slate-500 transition"
                  title="Предыдущая неделя"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={onNextWeek}
                  className="p-1 hover:bg-white hover:text-slate-800 rounded-md text-slate-500 transition"
                  title="Следующая неделя"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="text-sm sm:text-base font-semibold text-slate-800">
              {formatWeekRange(weekDays)}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
