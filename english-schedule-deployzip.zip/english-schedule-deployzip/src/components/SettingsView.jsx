import React, { useState, useEffect } from 'react';
import {
  Globe,
  LogOut,
  Database,
  CheckCircle2,
  AlertCircle,
  User,
  ShieldCheck,
  Loader2,
  Save,
} from 'lucide-react';
import { TIMEZONES, DEFAULT_TIMEZONE } from '../lib/types';
import { getSupabaseConfig, clearSupabaseConfig, getSupabase } from '../lib/supabase';

export default function SettingsView({
  user,
  profile,
  onProfileUpdated,
  onLogout,
  onOpenDbConfig,
  showToast,
}) {
  const [timezone, setTimezone] = useState(profile?.timezone || DEFAULT_TIMEZONE);
  const [teacherName, setTeacherName] = useState(profile?.teacher_name || 'Преподаватель');
  const [isSaving, setIsSaving] = useState(false);

  const dbConfig = getSupabaseConfig();

  useEffect(() => {
    if (profile) {
      setTimezone(profile.timezone || DEFAULT_TIMEZONE);
      setTeacherName(profile.teacher_name || 'Преподаватель');
    }
  }, [profile]);

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    const supabase = getSupabase();
    if (!supabase || !user) return;

    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          teacher_name: teacherName.trim(),
          timezone: timezone,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (error) throw error;

      showToast({
        type: 'success',
        title: 'Настройки сохранены',
        message: 'Часовой пояс и имя преподавателя обновлены',
      });

      if (onProfileUpdated) {
        onProfileUpdated({ ...profile, teacher_name: teacherName.trim(), timezone });
      }
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Ошибка сохранения настроек' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDisconnectDb = () => {
    if (
      window.confirm(
        'Отключить текущую базу данных? Вам потребуется повторно ввести ключи Supabase.'
      )
    ) {
      clearSupabaseConfig();
      window.location.reload();
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Карточка профиля преподавателя */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200/80 p-5 sm:p-7">
        <div className="flex items-center gap-3 pb-4 mb-6 border-b border-slate-100">
          <div className="p-3 bg-emerald-100 text-emerald-700 rounded-xl">
            <User className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">Профиль преподавателя</h2>
            <p className="text-xs text-slate-400">
              Личные данные и отображение расписания
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Имя преподавателя / Обращение
            </label>
            <input
              type="text"
              value={teacherName}
              onChange={(e) => setTeacherName(e.target.value)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Email преподавателя
            </label>
            <input
              type="email"
              value={user?.email || ''}
              disabled
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 bg-slate-50 text-slate-500 cursor-not-allowed"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Используется для авторизации в системе
            </p>
          </div>

          {/* Часовой пояс */}
          <div>
            <div className="flex items-center gap-1.5 mb-1">
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              <label className="text-xs font-semibold text-slate-700">
                Часовой пояс расписания
              </label>
            </div>
            <select
              value={timezone}
              onChange={(e) => setTimezone(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {TIMEZONES.map((tz) => (
                <option key={tz.id} value={tz.id}>
                  {tz.label} {tz.id === DEFAULT_TIMEZONE ? '(По умолчанию)' : ''}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-400 mt-1">
              Время занятий отображается в выбранном часовом поясе. По умолчанию: Europe/Bratislava.
            </p>
          </div>

          <div className="pt-3 flex justify-end">
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition flex items-center gap-2"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Сохранение...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Сохранить настройки
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Карточка состояния базы данных */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200/80 p-5 sm:p-7">
        <div className="flex items-center gap-3 pb-4 mb-4 border-b border-slate-100">
          <div className="p-3 bg-blue-100 text-blue-700 rounded-xl">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">Облачная база данных Supabase</h2>
            <p className="text-xs text-slate-400">
              Статус соединения и хранение данных
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-3 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-500">Статус:</span>
            <span className="flex items-center gap-1.5 text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Подключено к Supabase
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-500">Адрес проекта:</span>
            <span className="font-mono text-slate-700 truncate max-w-[240px] sm:max-w-xs">
              {dbConfig.url || 'Не указан'}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-500">Источник настроек:</span>
            <span className="text-slate-700 font-medium">
              {dbConfig.source === 'env'
                ? 'Переменные окружения (.env)'
                : 'Локальное хранилище браузера'}
            </span>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between gap-3 flex-wrap">
          <button
            type="button"
            onClick={onOpenDbConfig}
            className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold hover:underline"
          >
            Изменить параметры подключения Supabase
          </button>

          {dbConfig.source === 'localStorage' && (
            <button
              type="button"
              onClick={handleDisconnectDb}
              className="text-xs text-rose-600 hover:text-rose-700 hover:underline"
            >
              Сбросить ключи базы
            </button>
          )}
        </div>
      </div>

      {/* Карточка безопасности и выход */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200/80 p-5 sm:p-7 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-800">Выход из системы</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Завершить текущий сеанс преподавателя
          </p>
        </div>

        <button
          onClick={onLogout}
          className="px-4 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-600 rounded-xl text-xs sm:text-sm font-semibold transition border border-slate-200/80 hover:border-rose-200 flex items-center gap-2"
        >
          <LogOut className="w-4 h-4" />
          <span>Выйти</span>
        </button>
      </div>
    </div>
  );
}
