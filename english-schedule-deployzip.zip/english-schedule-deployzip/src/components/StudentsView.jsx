import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Phone,
  FileText,
  Calendar,
  Archive,
  ArchiveRestore,
  Edit2,
  Trash2,
  Plus,
  Clock,
  X,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { getSupabase } from '../lib/supabase';
import {
  addWeeks,
  formatDateFull,
  formatDateIso,
  formatTime,
  getMondayOfWeek,
  getTodayCalendarDate,
  getTodayIso,
  getWeekDays,
  parseISO,
} from '../lib/dateUtils';
import { computeDisplayLessons } from '../lib/schedule';

export default function StudentsView({
  students = [],
  lessons = [],
  recurrenceRules = [],
  timezone,
  onRefreshStudents,
  onOpenAddLessonForStudent,
  showToast,
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTab, setFilterTab] = useState('active'); // 'active', 'archived', 'all'

  // Модальное окно создания / редактирования ученика
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [note, setNote] = useState('');
  const [status, setStatus] = useState('active');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Модальное окно подтверждения удаления
  const [deleteCandidate, setDeleteCandidate] = useState(null);

  // Фильтрация
  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.phone && s.phone.includes(searchQuery));

    if (filterTab === 'active') return matchesSearch && s.status === 'active';
    if (filterTab === 'archived') return matchesSearch && s.status === 'archived';
    return matchesSearch;
  });

  const activeCount = students.filter((s) => s.status === 'active').length;
  const archivedCount = students.filter((s) => s.status === 'archived').length;

  const openAddModal = () => {
    setEditingStudent(null);
    setName('');
    setPhone('');
    setNote('');
    setStatus('active');
    setIsModalOpen(true);
  };

  const openEditModal = (student) => {
    setEditingStudent(student);
    setName(student.name);
    setPhone(student.phone || '');
    setNote(student.note || '');
    setStatus(student.status || 'active');
    setIsModalOpen(true);
  };

  const handleSaveStudent = async (e) => {
    e.preventDefault();
    const supabase = getSupabase();
    if (!supabase) return;

    if (!name.trim()) {
      showToast({ type: 'warning', message: 'Введите имя ученика' });
      return;
    }

    setIsSubmitting(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error('Пользователь не авторизован');

      if (editingStudent) {
        // Редактирование
        const { error } = await supabase
          .from('students')
          .update({
            name: name.trim(),
            phone: phone.trim(),
            note: note.trim(),
            status: status,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingStudent.id);

        if (error) throw error;

        showToast({
          type: 'success',
          title: 'Ученик обновлен',
          message: `Данные ученика «${name.trim()}» сохранены`,
        });
      } else {
        // Добавление
        const { error } = await supabase.from('students').insert({
          teacher_id: user.id,
          name: name.trim(),
          phone: phone.trim(),
          note: note.trim(),
          status: status,
        });

        if (error) throw error;

        showToast({
          type: 'success',
          title: 'Ученик добавлен',
          message: `Ученик «${name.trim()}» успешно создан`,
        });
      }

      onRefreshStudents();
      setIsModalOpen(false);
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Ошибка сохранения ученика' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Архивирование / разархивирование
  const handleToggleArchive = async (student) => {
    const supabase = getSupabase();
    if (!supabase) return;

    const newStatus = student.status === 'active' ? 'archived' : 'active';
    try {
      const { error } = await supabase
        .from('students')
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq('id', student.id);

      if (error) throw error;

      showToast({
        type: 'info',
        title: newStatus === 'archived' ? 'Ученик архивирован' : 'Ученик восстановлен',
        message:
          newStatus === 'archived'
            ? `«${student.name}» перемещен в архив. История уроков сохранена.`
            : `«${student.name}» возвращен в активный список.`,
      });

      onRefreshStudents();
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Ошибка изменения статуса' });
    }
  };

  // Удаление ученика (с проверкой уроков)
  const handleDeleteStudent = async (student) => {
    const supabase = getSupabase();
    if (!supabase) return;

    setIsSubmitting(true);
    try {
      const [lessonsResult, rulesResult] = await Promise.all([
        supabase
          .from('lessons')
          .select('id', { count: 'exact', head: true })
          .eq('student_id', student.id),
        supabase
          .from('recurrence_rules')
          .select('id', { count: 'exact', head: true })
          .eq('student_id', student.id),
      ]);
      if (lessonsResult.error) throw lessonsResult.error;
      if (rulesResult.error) throw rulesResult.error;
      if ((lessonsResult.count || 0) > 0 || (rulesResult.count || 0) > 0) {
        throw new Error(
          'У ученика есть уроки или серия занятий. Удаление заблокировано, чтобы не потерять историю. Переместите ученика в архив.'
        );
      }

      const { error } = await supabase.from('students').delete().eq('id', student.id);
      if (error) throw error;

      showToast({
        type: 'success',
        title: 'Ученик удален',
        message: `Ученик «${student.name}» удален`,
      });

      setDeleteCandidate(null);
      onRefreshStudents();
    } catch (err) {
      showToast({
        type: 'error',
        message: err.message || 'Не удалось удалить ученика',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Получить предстоящие уроки для конкретного ученика
  const getUpcomingLessons = (studentId) => {
    const todayIso = getTodayIso(timezone);
    const upcoming = lessons.filter(
      (lesson) =>
        !lesson.recurrence_rule_id &&
        lesson.student_id === studentId &&
        lesson.date >= todayIso &&
        lesson.status === 'scheduled'
    );
    const studentRules = recurrenceRules.filter(
      (rule) =>
        rule.student_id === studentId &&
        (!rule.until_date || rule.until_date >= todayIso)
    );

    for (const rule of studentRules) {
      const firstDate = rule.start_date > todayIso ? rule.start_date : todayIso;
      let monday = getMondayOfWeek(parseISO(firstDate));
      const upcomingForRule = [];
      const ruleLessons = lessons.filter(
        (lesson) => lesson.recurrence_rule_id === rule.id && lesson.student_id === studentId
      );
      for (let week = 0; week < 53; week += 1) {
        const weekDays = getWeekDays(monday);
        if (rule.until_date && rule.until_date < formatDateIso(weekDays[0])) break;
        upcomingForRule.push(
          ...computeDisplayLessons(weekDays, [rule], ruleLessons).filter(
            (lesson) =>
              lesson.student_id === studentId &&
              lesson.date >= todayIso &&
              lesson.status === 'scheduled'
          )
        );
        if (upcomingForRule.length >= 3) break;
        monday = addWeeks(monday, 1);
      }
      upcoming.push(...upcomingForRule);
    }

    const unique = new Map(upcoming.map((lesson) => [lesson.id, lesson]));
    return [...unique.values()]
      .sort((a, b) => a.date.localeCompare(b.date) || a.start_time.localeCompare(b.start_time))
      .slice(0, 3);
  };

  const getRecentLessons = (studentId) => {
    const todayIso = getTodayIso(timezone);
    return lessons
      .filter(
        (lesson) =>
          lesson.student_id === studentId &&
          (lesson.date < todayIso || lesson.status !== 'scheduled')
      )
      .sort((a, b) => b.date.localeCompare(a.date) || b.start_time.localeCompare(a.start_time))
      .slice(0, 3);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Верхняя панель: Поиск, фильтры и кнопка добавления */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200/80 p-4 sm:p-5 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        {/* Поиск */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Поиск по имени или телефону..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50/50"
          />
        </div>

        {/* Вкладки: Активные / В архиве / Все */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200/60 self-start sm:self-auto">
          <button
            onClick={() => setFilterTab('active')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              filterTab === 'active'
                ? 'bg-white text-emerald-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Активные ({activeCount})
          </button>
          <button
            onClick={() => setFilterTab('archived')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              filterTab === 'archived'
                ? 'bg-white text-emerald-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            В архиве ({archivedCount})
          </button>
          <button
            onClick={() => setFilterTab('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              filterTab === 'all'
                ? 'bg-white text-emerald-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Все ({students.length})
          </button>
        </div>

        {/* Добавить ученика */}
        <button
          onClick={openAddModal}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs transition font-semibold text-xs sm:text-sm shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          <span>Добавить ученика</span>
        </button>
      </div>

      {/* Список карточек учеников */}
      {filteredStudents.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 p-12 text-center">
          <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700">Ученики не найдены</h3>
          <p className="text-xs text-slate-400 mt-1 mb-5">
            {searchQuery
              ? 'Попробуйте изменить поисковый запрос'
              : 'В этом списке пока нет учеников. Добавьте первого ученика!'}
          </p>
          {!searchQuery && (
            <button
              onClick={openAddModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition"
            >
              <UserPlus className="w-4 h-4" />
              <span>Создать карточку ученика</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredStudents.map((s) => {
            const upcoming = getUpcomingLessons(s.id);
            const recent = getRecentLessons(s.id);
            const isArchived = s.status === 'archived';

            return (
              <div
                key={s.id}
                className={`bg-white rounded-2xl border p-5 shadow-xs transition hover:shadow-md flex flex-col justify-between ${
                  isArchived
                    ? 'border-slate-200 bg-slate-50/50 opacity-80'
                    : 'border-slate-200/80 hover:border-emerald-300'
                }`}
              >
                <div>
                  {/* Заголовок карточки: Имя + статус */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <h3 className="font-bold text-slate-800 text-base leading-tight">
                        {s.name}
                      </h3>
                      {s.phone && (
                        <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                          <Phone className="w-3.5 h-3.5 text-slate-400" />
                          <span>{s.phone}</span>
                        </div>
                      )}
                    </div>

                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
                        isArchived
                          ? 'bg-slate-100 text-slate-500 border-slate-200'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      }`}
                    >
                      {isArchived ? 'Архивный' : 'Активен'}
                    </span>
                  </div>

                  {/* Заметка об ученике */}
                  {s.note && (
                    <div className="mb-4 p-2.5 bg-slate-50 rounded-xl border border-slate-200/60 text-xs text-slate-600 flex items-start gap-2">
                      <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <span className="line-clamp-2">{s.note}</span>
                    </div>
                  )}

                  {/* Предстоящие занятия */}
                  <div className="mb-4">
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Предстоящие уроки:</span>
                    </div>

                    {upcoming.length === 0 ? (
                      <div className="text-xs text-slate-400 italic">Нет запланированных уроков</div>
                    ) : (
                      <div className="space-y-1.5">
                        {upcoming.map((u) => (
                          <div
                            key={u.id}
                            className="text-xs bg-slate-50/90 hover:bg-slate-100 p-2 rounded-lg border border-slate-200/60 flex items-center justify-between"
                          >
                            <span className="font-medium text-slate-700">
                              {formatDateFull(u.date)}
                            </span>
                            <span className="font-bold text-slate-800">
                              {formatTime(u.start_time)} ({u.duration_minutes}м)
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="mb-4">
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Недавняя история:</span>
                    </div>
                    {recent.length === 0 ? (
                      <div className="text-xs text-slate-400 italic">Записей пока нет</div>
                    ) : (
                      <div className="space-y-1.5">
                        {recent.map((lesson) => (
                          <div
                            key={lesson.id}
                            className="text-xs bg-slate-50/90 p-2 rounded-lg border border-slate-200/60 flex items-center justify-between gap-2"
                          >
                            <span className="font-medium text-slate-700">
                              {formatDateFull(lesson.date)}
                            </span>
                            <span className="font-bold text-slate-800">
                              {formatTime(lesson.start_time)} ·{' '}
                              {lesson.status === 'completed'
                                ? 'Проведён'
                                : lesson.status === 'cancelled'
                                  ? 'Отменён'
                                  : 'Запланирован'}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Нижняя панель действий */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-1 flex-wrap">
                  {/* Записать на урок */}
                  {!isArchived && (
                    <button
                      onClick={() => onOpenAddLessonForStudent(s.id)}
                      className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold text-xs rounded-xl border border-emerald-200 flex items-center gap-1 transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Записать на урок</span>
                    </button>
                  )}

                  <div className="flex items-center gap-1">
                    {/* Редактировать */}
                    <button
                      onClick={() => openEditModal(s)}
                      className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
                      title="Редактировать"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    {/* В архив / из архива */}
                    <button
                      onClick={() => handleToggleArchive(s)}
                      className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
                      title={isArchived ? 'Восстановить из архива' : 'В архив'}
                    >
                      {isArchived ? (
                        <ArchiveRestore className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Archive className="w-3.5 h-3.5" />
                      )}
                    </button>

                    {/* Удалить */}
                    <button
                      onClick={() => setDeleteCandidate(s)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                      title="Удалить ученика"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ======================================================== */}
      {/* МОДАЛЬНОЕ ОКНО СОЗДАНИЯ / РЕДАКТИРОВАНИЯ УЧЕНИКА        */}
      {/* ======================================================== */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-5 sm:p-7 border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-800">
                {editingStudent ? 'Редактировать ученика' : 'Новый ученик'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStudent} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Имя и фамилия *
                </label>
                <input
                  type="text"
                  placeholder="Михаил Иванов"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Телефон / контакт
                </label>
                <input
                  type="tel"
                  placeholder="+7 999 123-45-67 или @telegram"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Заметка (уровень, ссылка на урок, цели)
                </label>
                <textarea
                  rows={3}
                  placeholder="Уровень B1, подготовка к IELTS, ссылка на Skype/Zoom..."
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Статус</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="active">Активный ученик</option>
                  <option value="archived">В архиве (завершил занятия)</option>
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-semibold rounded-xl shadow-xs transition flex items-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Сохранение...
                    </>
                  ) : (
                    'Сохранить'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* МОДАЛЬНОЕ ОКНО ПОДТВЕРЖДЕНИЯ УДАЛЕНИЯ УЧЕНИКА          */}
      {/* ======================================================== */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-100">
            <div className="flex items-center gap-3 mb-4 text-rose-600">
              <AlertCircle className="w-6 h-6 shrink-0" />
              <h3 className="text-base font-bold text-slate-800">Удалить ученика?</h3>
            </div>
            <p className="text-sm text-slate-600 mb-3">
              Вы уверены, что хотите удалить ученика <b>«{deleteCandidate.name}»</b>?
            </p>
            <p className="text-xs text-amber-700 bg-amber-50 p-3 rounded-xl border border-amber-200 mb-5">
              Если у ученика уже есть уроки или серия, удаление будет заблокировано, чтобы сохранить историю. В таком случае выберите <b>«В архив»</b>.
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteCandidate(null)}
                className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800"
              >
                Отмена
              </button>
              <button
                type="button"
                onClick={() => handleDeleteStudent(deleteCandidate)}
                disabled={isSubmitting}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold rounded-xl shadow-xs transition"
              >
                Удалить ученика
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
