import React, { useState, useEffect, useCallback, useRef } from 'react';
import Header from './components/Header';
import WeeklySchedule from './components/WeeklySchedule';
import StudentsView from './components/StudentsView';
import SettingsView from './components/SettingsView';
import AddLessonModal from './components/AddLessonModal';
import LessonModal from './components/LessonModal';
import AuthModal from './components/AuthModal';
import DbSetupModal from './components/DbSetupModal';
import Toast from './components/Toast';
import {
  getMondayOfWeek,
  getWeekDays,
  addWeeks,
  subWeeks,
  getTodayCalendarDate,
  getTodayIso,
} from './lib/dateUtils';
import { getSupabase, isSupabaseConfigured } from './lib/supabase';
import { DEFAULT_TIMEZONE } from './lib/types';
import { computeDisplayLessons } from './lib/schedule';
import { Loader2 } from 'lucide-react';

export default function App() {
  // Конфигурация Supabase
  const [dbConfigured, setDbConfigured] = useState(isSupabaseConfigured());
  const [isDbSetupModalOpen, setIsDbSetupModalOpen] = useState(false);

  // Сессия пользователя
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Навигация
  const [activeTab, setActiveTab] = useState('schedule'); // 'schedule' | 'students' | 'settings'

  // Неделя в расписании (понедельник)
  const [currentMonday, setCurrentMonday] = useState(() =>
    getMondayOfWeek(getTodayCalendarDate(DEFAULT_TIMEZONE))
  );
  const weekDays = getWeekDays(currentMonday);

  // Данные
  const [students, setStudents] = useState([]);
  const [recurrenceRules, setRecurrenceRules] = useState([]);
  const [storedLessons, setStoredLessons] = useState([]);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [schemaSetupError, setSchemaSetupError] = useState('');
  const [isCheckingSchema, setIsCheckingSchema] = useState(false);
  const [schemaCheckFeedback, setSchemaCheckFeedback] = useState('');
  const [databaseCheckAttempt, setDatabaseCheckAttempt] = useState(0);
  const manualSchemaCheckRequested = useRef(false);

  // Модальные окна уроков
  const [isAddLessonOpen, setIsAddLessonOpen] = useState(false);
  const [addLessonInitialDate, setAddLessonInitialDate] = useState('');
  const [addLessonInitialTime, setAddLessonInitialTime] = useState('10:00');
  const [addLessonInitialStudentId, setAddLessonInitialStudentId] = useState('');

  const [selectedLesson, setSelectedLesson] = useState(null);

  // Уведомления (Toasts)
  const [toast, setToast] = useState(null);
  const showToast = useCallback((t) => setToast(t), []);
  const handleSupabaseConfigSaved = useCallback(() => {
    // Recreate one Supabase client and auth subscription from the saved config.
    window.location.reload();
  }, []);

  // 1. Проверка сессии при запуске
  useEffect(() => {
    if (!dbConfigured) {
      setAuthLoading(false);
      return;
    }

    const supabase = getSupabase();
    if (!supabase) {
      setAuthLoading(false);
      return;
    }

    let isMounted = true;
    supabase.auth.getSession()
      .then(({ data: { session }, error }) => {
        if (error) throw error;
        if (isMounted) {
          setUser(session?.user ?? null);
          setAuthLoading(false);
        }
      })
      .catch((error) => {
        console.error('Ошибка проверки сессии:', error);
        if (isMounted) {
          setAuthLoading(false);
          showToast({
            type: 'error',
            title: 'Не удалось проверить вход',
            message: error.message || 'Проверьте соединение с Supabase',
          });
        }
      });

    // Слушатель смены авторизации
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, [dbConfigured, showToast]);

  useEffect(() => {
    if (profile?.timezone) {
      setCurrentMonday(getMondayOfWeek(getTodayCalendarDate(profile.timezone)));
    }
  }, [profile?.timezone]);

  // 2. Загрузка профиля преподавателя
  const loadProfile = useCallback(async () => {
    if (!user) return;
    const supabase = getSupabase();
    if (!supabase) return;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (data) {
        setProfile(data);
      } else {
        if (error && error.code !== 'PGRST116') throw error;
        // Если профиля нет (триггер еще не сработал), создаем базовый
        const defaultProfile = {
          id: user.id,
          teacher_name: user.user_metadata?.full_name || 'Преподаватель',
          timezone: DEFAULT_TIMEZONE,
        };
        const { data: savedProfile, error: saveError } = await supabase
          .from('profiles')
          .upsert(defaultProfile, { onConflict: 'id', ignoreDuplicates: true })
          .select()
          .single();
        if (saveError) throw saveError;
        setProfile(savedProfile || defaultProfile);
      }
    } catch (e) {
      console.error('Ошибка загрузки профиля:', e);
      showToast({ type: 'error', message: e.message || 'Не удалось загрузить профиль' });
    }
  }, [user, showToast]);

  // 3. Загрузка учеников
  const loadStudents = useCallback(async () => {
    if (!user) return;
    const supabase = getSupabase();
    if (!supabase) return;

    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('teacher_id', user.id)
        .order('name', { ascending: true });

      if (error) throw error;
      setStudents(data || []);
    } catch (e) {
      console.error('Ошибка загрузки учеников:', e);
      showToast({ type: 'error', message: e.message || 'Не удалось загрузить учеников' });
    }
  }, [user, showToast]);

  // 4. Загрузка уроков и правил повторения
  const loadScheduleData = useCallback(async () => {
    if (!user) return;
    const supabase = getSupabase();
    if (!supabase) return;

    setIsDataLoading(true);
    try {
      // Загружаем правила повторения
      const { data: rulesData, error: rulesErr } = await supabase
        .from('recurrence_rules')
        .select('*, student:students(id, name, phone, status)')
        .eq('teacher_id', user.id);

      if (rulesErr) throw rulesErr;
      setRecurrenceRules(rulesData || []);

      const { error: migrationCheckError } = await supabase
        .from('lessons')
        .select('original_date')
        .limit(0);
      if (migrationCheckError) {
        if (['42703', 'PGRST204'].includes(migrationCheckError.code)) {
          throw new Error(
            'Схема Supabase устарела. Сначала выполните новую миграцию из supabase/migrations.'
          );
        }
        throw migrationCheckError;
      }

      // Загружаем все сохранённые уроки постранично: история учеников,
      // переносы и проверка конфликтов не должны ограничиваться текущей неделей.
      const allLessons = [];
      const pageSize = 1000;
      for (let offset = 0; ; offset += pageSize) {
        const { data: page, error: pageError } = await supabase
          .from('lessons')
          .select('*, student:students(id, name, phone, status), recurrence_rule:recurrence_rules(*)')
          .eq('teacher_id', user.id)
          .order('date', { ascending: true })
          .order('id', { ascending: true })
          .range(offset, offset + pageSize - 1);

        if (pageError) throw pageError;
        allLessons.push(...(page || []));
        if (!page || page.length < pageSize) break;
      }
      setStoredLessons(allLessons);
    } catch (e) {
      console.error('Ошибка загрузки расписания:', e);
      showToast({
        type: 'error',
        title: 'Ошибка базы данных',
        message: e.message || 'Не удалось загрузить расписание',
      });
    } finally {
      setIsDataLoading(false);
    }
  }, [user, showToast]);

  // Сначала проверяем схему, чтобы вместо серии ошибок показать один
  // понятный экран, если Supabase ещё не подготовлен.
  useEffect(() => {
    if (!user) {
      setSchemaSetupError('');
      setIsCheckingSchema(false);
      setSchemaCheckFeedback('');
      return undefined;
    }

    let isMounted = true;
    const wasManualCheck = manualSchemaCheckRequested.current;
    manualSchemaCheckRequested.current = false;
    const setManualCheckFeedback = (message) => {
      if (wasManualCheck) setSchemaCheckFeedback(message);
    };
    const checkAndLoad = async () => {
      try {
        const checks = await Promise.all([
          getSupabase().from('profiles').select('id').limit(0),
          getSupabase().from('students').select('id').limit(0),
          getSupabase().from('recurrence_rules').select('id').limit(0),
          getSupabase().from('lessons').select('id, original_date').limit(0),
        ]);
        if (!isMounted) return;

        const errors = checks.map((result) => result.error).filter(Boolean);
        const missingTables = errors.filter((error) => error.code === 'PGRST205');
        const missingMigration = errors.find(
          (error) => ['42703', 'PGRST204'].includes(error.code)
        );
        if (missingTables.length === checks.length) {
          setSchemaSetupError(
            'Supabase подключён, но в выбранном проекте нет таблиц приложения. Подключение проверяет URL и ключ, но не создаёт таблицы.'
          );
          setManualCheckFeedback(
            'Проверка завершена: таблицы по-прежнему не найдены. Нажатие этой кнопки только проверяет схему — SQL нужно выполнить в Supabase → SQL Editor.'
          );
          return;
        }
        if (missingTables.length) {
          setSchemaSetupError(
            'В Supabase отсутствуют некоторые таблицы приложения. Не запускайте schema.sql поверх частичной базы: сначала проверьте выбранный проект и структуру таблиц.'
          );
          setManualCheckFeedback(
            'Проверка завершена: схема неполная. Сначала убедитесь, что подключён правильный проект Supabase.'
          );
          return;
        }
        if (missingMigration) {
          setSchemaSetupError(
            'В Supabase не применено обновление структуры для переносов уроков. Выполните миграцию из supabase/migrations в Supabase → SQL Editor.'
          );
          setManualCheckFeedback(
            'Проверка завершена: базовые таблицы есть, но миграция ещё не применена.'
          );
          return;
        }
        if (errors.length) {
          const message = `Не удалось проверить Supabase: ${errors[0].message}`;
          setSchemaSetupError(message);
          setManualCheckFeedback(message);
          return;
        }

        setSchemaSetupError('');
        setSchemaCheckFeedback('');
        await Promise.all([loadProfile(), loadStudents(), loadScheduleData()]);
      } catch (error) {
        if (isMounted) {
          const message = `Не удалось проверить Supabase: ${error.message}`;
          setSchemaSetupError(message);
          setManualCheckFeedback(message);
        }
      } finally {
        if (isMounted) setIsCheckingSchema(false);
      }
    };

    checkAndLoad();
    return () => {
      isMounted = false;
    };
  }, [
    user,
    loadProfile,
    loadStudents,
    loadScheduleData,
    databaseCheckAttempt,
  ]);

  // 5. Формирование полного списка уроков для отображения в неделе
  // (Объединение разовых уроков, правил повторения и исключений)
  const displayLessons = React.useMemo(() => {
    return computeDisplayLessons(weekDays, recurrenceRules, storedLessons);
  }, [weekDays, recurrenceRules, storedLessons]);

  // Навигация по неделям
  const handlePrevWeek = () => setCurrentMonday((prev) => subWeeks(prev, 1));
  const handleNextWeek = () => setCurrentMonday((prev) => addWeeks(prev, 1));
  const handleToday = () =>
    setCurrentMonday(
      getMondayOfWeek(getTodayCalendarDate(profile?.timezone || DEFAULT_TIMEZONE))
    );

  // Открытие модального окна добавления урока
  const handleOpenAddLesson = (date, time, studentId = '') => {
    setAddLessonInitialDate(date || getTodayIso(profile?.timezone || DEFAULT_TIMEZONE));
    setAddLessonInitialTime(time || '10:00');
    setAddLessonInitialStudentId(studentId);
    setIsAddLessonOpen(true);
  };

  // Выход из аккаунта
  const handleLogout = async () => {
    const supabase = getSupabase();
    if (supabase) {
      await supabase.auth.signOut();
    }
    setUser(null);
    setProfile(null);
    setStudents([]);
    setRecurrenceRules([]);
    setStoredLessons([]);
    showToast({ type: 'info', message: 'Вы вышли из системы' });
  };

  // 1. Экран загрузки
  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <Loader2 className="w-8 h-8 text-emerald-600 animate-spin mb-3" />
        <div className="text-sm font-semibold text-slate-700">Загрузка расписания...</div>
      </div>
    );
  }

  // 2. Если база Supabase не настроена вообще (например при первом открытии в Netlify Drop)
  if (!dbConfigured) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <DbSetupModal
          isOpen={true}
          isMandatory={true}
          onConfigSaved={handleSupabaseConfigSaved}
        />
        <Toast toast={toast} onClose={() => setToast(null)} />
      </div>
    );
  }

  // 3. Если пользователь не авторизован -> экран входа
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <AuthModal
          onAuthSuccess={(loggedUser) => {
            setUser(loggedUser);
            showToast({
              type: 'success',
              title: 'Добро пожаловать!',
              message: 'Вы успешно вошли в систему',
            });
          }}
          onOpenDbConfig={() => setIsDbSetupModalOpen(true)}
        />
        <DbSetupModal
          isOpen={isDbSetupModalOpen}
          onClose={() => setIsDbSetupModalOpen(false)}
          onConfigSaved={handleSupabaseConfigSaved}
        />
        <Toast toast={toast} onClose={() => setToast(null)} />
      </div>
    );
  }

  if (schemaSetupError) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-xl w-full bg-white border border-amber-200 rounded-2xl p-6 sm:p-8 shadow-sm">
          <h1 className="text-xl font-bold text-slate-800">Требуется настроить базу Supabase</h1>
          <p className="mt-3 text-sm leading-6 text-slate-600">{schemaSetupError}</p>
          <p className="mt-3 text-sm leading-6 text-slate-600">
            Успешное подключение подтверждает только URL и публичный ключ — оно не создаёт таблицы.
            Новый аккаунт преподавателя их тоже не создаст.
          </p>
          <p className="mt-3 text-sm leading-6 text-slate-600">
            Сначала проверьте, что подключён именно тот проект Supabase, которым пользовались раньше.
            Если проект новый и пустой, выполните schema.sql, затем
            {' '}supabase/migrations/20261010000000_schedule_safety.sql в Supabase → SQL Editor.
            Если там должны быть прежние ученики или уроки, не создавайте новый проект и не запускайте
            schema.sql: сначала проверьте адрес проекта. Миграцию применяйте только к существующей
            схеме приложения.
          </p>
          {schemaCheckFeedback && (
            <p
              role="status"
              aria-live="polite"
              className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm leading-6 text-amber-900"
            >
              {schemaCheckFeedback}
            </p>
          )}
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={() => {
                setSchemaCheckFeedback('Проверяем таблицы в выбранном проекте Supabase…');
                setIsCheckingSchema(true);
                manualSchemaCheckRequested.current = true;
                setDatabaseCheckAttempt((attempt) => attempt + 1);
              }}
              disabled={isCheckingSchema}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-sm font-semibold"
            >
              {isCheckingSchema ? 'Проверяем…' : 'Проверить снова'}
            </button>
            <button
              type="button"
              onClick={() => setIsDbSetupModalOpen(true)}
              className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-sm font-semibold"
            >
              Настроить подключение
            </button>
            <button
              type="button"
              onClick={handleLogout}
              className="px-4 py-2.5 rounded-xl text-slate-600 text-sm font-medium"
            >
              Выйти
            </button>
          </div>
          <DbSetupModal
            isOpen={isDbSetupModalOpen}
            onClose={() => setIsDbSetupModalOpen(false)}
            onConfigSaved={handleSupabaseConfigSaved}
          />
        </div>
      </div>
    );
  }

  // 4. Основной рабочий интерфейс
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col">
      {/* Шапка сайта */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        weekDays={weekDays}
        onPrevWeek={handlePrevWeek}
        onNextWeek={handleNextWeek}
        onToday={handleToday}
        onOpenAddLesson={() => handleOpenAddLesson()}
      />

      {/* Основной контент */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 lg:p-8">
        {activeTab === 'schedule' && (
          <WeeklySchedule
            weekDays={weekDays}
            lessons={displayLessons}
            recurrenceRules={recurrenceRules}
            timezone={profile?.timezone || DEFAULT_TIMEZONE}
            onSelectLesson={(lesson) => setSelectedLesson(lesson)}
            onAddLessonAtTime={(date, time) => handleOpenAddLesson(date, time)}
          />
        )}

        {activeTab === 'students' && (
          <StudentsView
            students={students}
            lessons={storedLessons}
            recurrenceRules={recurrenceRules}
            timezone={profile?.timezone || DEFAULT_TIMEZONE}
            onRefreshStudents={loadStudents}
            onOpenAddLessonForStudent={(studentId) => handleOpenAddLesson(null, '10:00', studentId)}
            showToast={showToast}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            user={user}
            profile={profile}
            onProfileUpdated={(updated) => setProfile(updated)}
            onLogout={handleLogout}
            onOpenDbConfig={() => setIsDbSetupModalOpen(true)}
            showToast={showToast}
          />
        )}
      </main>

      {/* Модальное окно добавления урока */}
      <AddLessonModal
        isOpen={isAddLessonOpen}
        onClose={() => setIsAddLessonOpen(false)}
        initialDate={addLessonInitialDate}
        initialTime={addLessonInitialTime}
        initialStudentId={addLessonInitialStudentId}
        students={students}
        existingLessons={displayLessons}
        existingRules={recurrenceRules}
        timezone={profile?.timezone || DEFAULT_TIMEZONE}
        onLessonCreated={loadScheduleData}
        onStudentCreated={(newStudent) => {
          loadStudents();
          setAddLessonInitialStudentId(newStudent.id);
        }}
        showToast={showToast}
      />

      {/* Модальное окно просмотра / редактирования урока */}
      <LessonModal
        isOpen={Boolean(selectedLesson)}
        onClose={() => setSelectedLesson(null)}
        lesson={selectedLesson}
        existingLessons={storedLessons}
        recurrenceRules={recurrenceRules}
        onLessonUpdated={loadScheduleData}
        showToast={showToast}
      />

      {/* Модальное окно настройки базы данных (вызывается из настроек) */}
      <DbSetupModal
        isOpen={isDbSetupModalOpen}
        onClose={() => setIsDbSetupModalOpen(false)}
        onConfigSaved={handleSupabaseConfigSaved}
      />

      {/* Всплывающие уведомления */}
      <Toast toast={toast} onClose={() => setToast(null)} />
    </div>
  );
}
