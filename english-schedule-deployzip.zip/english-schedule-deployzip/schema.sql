-- ==============================================================================
-- СХЕМА БАЗЫ ДАННЫХ ДЛЯ ПРИЛОЖЕНИЯ «РАСПИСАНИЕ ПРЕПОДАВАТЕЛЯ АНГЛИЙСКОГО»
-- Выполните этот скрипт в Supabase -> SQL Editor -> New query -> Нажмите "Run"
-- ==============================================================================

-- 1. ТАБЛИЦА ПРОФИЛЕЙ ПРЕПОДАВАТЕЛЯ
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    teacher_name TEXT NOT NULL DEFAULT 'Преподаватель',
    timezone TEXT NOT NULL DEFAULT 'Europe/Bratislava',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. ТАБЛИЦА УЧЕНИКОВ
CREATE TABLE IF NOT EXISTS public.students (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    teacher_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    note TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    UNIQUE (id, teacher_id)
);

-- 3. ТАБЛИЦА ПРАВИЛ ПОВТОРЕНИЯ ЗАНЯТИЙ (RECURRENCE RULES)
CREATE TABLE IF NOT EXISTS public.recurrence_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    teacher_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    student_id UUID NOT NULL,
    freq TEXT NOT NULL CHECK (freq IN ('daily', 'weekly')),
    by_weekdays INTEGER[] NOT NULL DEFAULT '{}', -- 1 = Пн, 2 = Вт, 3 = Ср, 4 = Чт, 5 = Пт, 6 = Сб, 7 = Вс
    start_date DATE NOT NULL,
    start_time TIME NOT NULL,
    duration_minutes INTEGER NOT NULL DEFAULT 60 CHECK (duration_minutes IN (30, 45, 60, 90)),
    until_date DATE, -- NULL означает без даты окончания (бессрочно)
    note TEXT DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    UNIQUE (id, teacher_id),
    CONSTRAINT recurrence_rules_student_teacher_fkey
        FOREIGN KEY (student_id, teacher_id)
        REFERENCES public.students(id, teacher_id) ON DELETE RESTRICT
);

-- 4. ТАБЛИЦА ЗАНЯТИЙ (РАЗОВЫЕ УРОКИ И ИСКЛЮЧЕНИЯ/ПЕРЕНОСЫ ПОВТОРЯЮЩИХСЯ СЕРИЙ)
CREATE TABLE IF NOT EXISTS public.lessons (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    teacher_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    student_id UUID NOT NULL,
    recurrence_rule_id UUID,
    date DATE NOT NULL,
    original_date DATE,
    start_time TIME NOT NULL,
    duration_minutes INTEGER NOT NULL DEFAULT 60 CHECK (duration_minutes IN (30, 45, 60, 90)),
    note TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled')),
    is_exception BOOLEAN NOT NULL DEFAULT false, -- true для индивидуальных изменений в повторяющейся серии
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    CONSTRAINT lessons_student_teacher_fkey
        FOREIGN KEY (student_id, teacher_id)
        REFERENCES public.students(id, teacher_id) ON DELETE RESTRICT,
    CONSTRAINT lessons_recurrence_teacher_fkey
        FOREIGN KEY (recurrence_rule_id, teacher_id)
        REFERENCES public.recurrence_rules(id, teacher_id) ON DELETE RESTRICT
);

-- ИНДЕКСЫ ДЛЯ БЫСТРОЙ ВЫБОРКИ РАСПИСАНИЯ
CREATE INDEX IF NOT EXISTS idx_students_teacher_id ON public.students(teacher_id);
CREATE INDEX IF NOT EXISTS idx_students_status ON public.students(status);
CREATE INDEX IF NOT EXISTS idx_rules_teacher_id ON public.recurrence_rules(teacher_id);
CREATE INDEX IF NOT EXISTS idx_rules_student_id ON public.recurrence_rules(student_id);
CREATE INDEX IF NOT EXISTS idx_lessons_teacher_date ON public.lessons(teacher_id, date);
CREATE INDEX IF NOT EXISTS idx_lessons_student_id ON public.lessons(student_id);
CREATE INDEX IF NOT EXISTS idx_lessons_rule_id ON public.lessons(recurrence_rule_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_lessons_unique_rule_original_date
    ON public.lessons(recurrence_rule_id, original_date);

-- ==============================================================================
-- НАСТРОЙКА БЕЗОПАСНОСТИ (ROW LEVEL SECURITY - RLS)
-- Преподаватель имеет доступ ТОЛЬКО к своим данным!
-- ==============================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.recurrence_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;

GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles, public.students,
    public.recurrence_rules, public.lessons TO authenticated;

-- Политики для profiles
DROP POLICY IF EXISTS "Пользователь управляет своим профилем" ON public.profiles;
CREATE POLICY "Пользователь управляет своим профилем"
    ON public.profiles FOR ALL
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Политики для students
DROP POLICY IF EXISTS "Преподаватель видит своих учеников" ON public.students;
CREATE POLICY "Преподаватель видит своих учеников"
    ON public.students FOR SELECT
    USING (auth.uid() = teacher_id);

DROP POLICY IF EXISTS "Преподаватель добавляет своих учеников" ON public.students;
CREATE POLICY "Преподаватель добавляет своих учеников"
    ON public.students FOR INSERT
    WITH CHECK (auth.uid() = teacher_id);

DROP POLICY IF EXISTS "Преподаватель обновляет своих учеников" ON public.students;
CREATE POLICY "Преподаватель обновляет своих учеников"
    ON public.students FOR UPDATE
    USING (auth.uid() = teacher_id)
    WITH CHECK (auth.uid() = teacher_id);

DROP POLICY IF EXISTS "Преподаватель удаляет своих учеников" ON public.students;
CREATE POLICY "Преподаватель удаляет своих учеников"
    ON public.students FOR DELETE
    USING (auth.uid() = teacher_id);

-- Политики для recurrence_rules
DROP POLICY IF EXISTS "Преподаватель управляет своими правилами повторения" ON public.recurrence_rules;
CREATE POLICY "Преподаватель управляет своими правилами повторения"
    ON public.recurrence_rules FOR ALL
    USING (auth.uid() = teacher_id)
    WITH CHECK (auth.uid() = teacher_id);

-- Политики для lessons
DROP POLICY IF EXISTS "Преподаватель управляет своими уроками" ON public.lessons;
CREATE POLICY "Преподаватель управляет своими уроками"
    ON public.lessons FOR ALL
    USING (auth.uid() = teacher_id)
    WITH CHECK (auth.uid() = teacher_id);

-- ==============================================================================
-- ТРИГГЕР ДЛЯ АВТОМАТИЧЕСКОГО СОЗДАНИЯ ПРОФИЛЯ ПРИ РЕГИСТРАЦИИ
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, teacher_name, timezone)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'full_name', 'Преподаватель'),
        'Europe/Bratislava'
    )
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
