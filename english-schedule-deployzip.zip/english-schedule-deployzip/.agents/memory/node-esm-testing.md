---
name: Native Node ESM tests
description: Local module-resolution constraint for directly running shared logic tests with Node.
---

When test scripts import project helpers directly through native Node ESM, use explicit `.js` suffixes on relative imports. Vite may resolve extensionless imports, but Node's native ESM loader does not.

**Why:** Direct Node test runs failed on Vite-compatible extensionless imports; explicit suffixes let the tests exercise production helper modules without bundling.

**How to apply:** Preserve explicit `.js` suffixes in helper-to-helper imports used by Node-run tests. Keep the app's imports consistent with the existing Vite convention where needed.
